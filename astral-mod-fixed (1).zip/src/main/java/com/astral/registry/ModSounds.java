package com.astral.registry;

import com.astral.AstralMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, AstralMod.MODID);

    public static final RegistryObject<SoundEvent> WISH_SPAWN = register("wish.spawn");
    public static final RegistryObject<SoundEvent> WISH_GRANT = register("wish.grant");
    public static final RegistryObject<SoundEvent> WISH_GRANT_RARE = register("wish.grant_rare");
    public static final RegistryObject<SoundEvent> ALTAR_SUMMON = register("altar.summon");
    public static final RegistryObject<SoundEvent> WISH_SHOWER = register("wish.shower");

    private ModSounds() {}

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AstralMod.MODID, name)));
    }
}
