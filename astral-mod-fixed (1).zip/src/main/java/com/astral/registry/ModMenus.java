package com.astral.registry;

import com.astral.AstralMod;
import com.astral.pillow.PocketMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, AstralMod.MODID);

    public static final RegistryObject<MenuType<PocketMenu>> POCKET = MENUS.register("pocket",
            () -> IForgeMenuType.create((id, inventory, buffer) -> new PocketMenu(id, inventory)));

    private ModMenus() {}
}
