package com.astral.block;

import com.astral.registry.ModSounds;
import com.astral.wish.WishEntity;
import com.astral.wish.WishKind;
import com.astral.wish.WishSpawner;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Vector3f;

/**
 * Altar de Deseos: ofrece una esencia (clic derecho) y el alma vuelve a caer del cielo justo encima.
 * Subete al altar para recibirla: asi no se pierde ninguna esencia.
 */
public class WishAltarBlock extends Block {
    private static final VoxelShape SHAPE = Shapes.or(
            Block.box(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D),
            Block.box(3.0D, 2.0D, 3.0D, 13.0D, 7.0D, 13.0D),
            Block.box(0.0D, 7.0D, 0.0D, 16.0D, 8.0D, 16.0D));

    public WishAltarBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        WishKind kind = WishKind.fromEssence(held.getItem());
        if (kind == null) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.astral.altar_hint"), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }
        Item essence = held.getItem();
        if (player.getCooldowns().isOnCooldown(essence)) {
            return InteractionResult.CONSUME;
        }
        if (!serverLevel.getEntitiesOfClass(WishEntity.class, new AABB(pos).inflate(48.0D)).isEmpty()) {
            player.displayClientMessage(Component.translatable("message.astral.altar_busy"), true);
            return InteractionResult.CONSUME;
        }
        if (!player.getAbilities().instabuild) {
            held.shrink(1);
        }
        player.getCooldowns().addCooldown(essence, 60);

        double y = Math.min(serverLevel.getMaxBuildHeight() - 5, pos.getY() + 32);
        WishEntity wish = WishSpawner.spawn(serverLevel, kind, pos.getX() + 0.5D, y, pos.getZ() + 0.5D);
        if (wish != null) {
            wish.setCalm(true);
        }
        serverLevel.playSound(null, pos, ModSounds.ALTAR_SUMMON.get(), SoundSource.BLOCKS, 1.4F, 1.0F);
        DustParticleOptions dust = new DustParticleOptions(new Vector3f(kind.r, kind.g, kind.b), 1.6F);
        for (int i = 0; i < 24; i++) {
            serverLevel.sendParticles(dust, pos.getX() + 0.5D, pos.getY() + 1.0D + i * 0.35D, pos.getZ() + 0.5D,
                    2, 0.15D, 0.05D, 0.15D, 0.0D);
        }
        serverLevel.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                20, 0.3D, 0.1D, 0.3D, 0.08D);
        return InteractionResult.CONSUME;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(6) == 0) {
            level.addParticle(ParticleTypes.END_ROD,
                    pos.getX() + 0.3D + random.nextDouble() * 0.4D, pos.getY() + 0.7D,
                    pos.getZ() + 0.3D + random.nextDouble() * 0.4D, 0.0D, 0.03D, 0.0D);
        }
    }
}
