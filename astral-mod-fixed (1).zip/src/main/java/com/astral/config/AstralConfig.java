package com.astral.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Ajustes del mod (archivo config/astral-common.toml). */
public final class AstralConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue WISH_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.IntValue WISH_FALL_HEIGHT;
    public static final ForgeConfigSpec.IntValue MAX_NEARBY_WISHES;
    public static final ForgeConfigSpec.DoubleValue SHOWER_CHANCE;
    public static final ForgeConfigSpec.DoubleValue WISH_DURATION_MULTIPLIER;
    public static final ForgeConfigSpec.BooleanValue PILLOW_GUARD_ENABLED;
    public static final ForgeConfigSpec.IntValue POCKET_RADIUS;
    public static final ForgeConfigSpec.DoubleValue RIDE_SPEED;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.comment("Los Deseos: almas que caen del cielo").push("wishes");
        WISH_INTERVAL_SECONDS = builder
                .comment("Cada cuantos segundos, de media, cae un deseo cerca de cada jugador.")
                .defineInRange("intervalSeconds", 240, 10, 36000);
        WISH_FALL_HEIGHT = builder
                .comment("Altura (en bloques) desde la que empiezan a caer.")
                .defineInRange("fallHeight", 45, 15, 150);
        MAX_NEARBY_WISHES = builder
                .comment("Maximo de deseos cayendo a la vez cerca de un jugador.")
                .defineInRange("maxNearby", 2, 1, 20);
        SHOWER_CHANCE = builder
                .comment("Probabilidad (0 a 1) de que cada noche haya una Lluvia de Deseos.")
                .defineInRange("showerChancePerNight", 0.10D, 0.0D, 1.0D);
        WISH_DURATION_MULTIPLIER = builder
                .comment("Multiplicador de la duracion de los poderes (1.0 = 10 min los comunes, 15 min dorado y oscuro).")
                .defineInRange("durationMultiplier", 1.0D, 0.1D, 20.0D);
        builder.pop();

        builder.comment("Almohada Magica").push("pillow");
        PILLOW_GUARD_ENABLED = builder
                .comment("Si es false, la almohada en la cabeza ya no protege de los ataques (util en servidores PvP).")
                .define("guardEnabled", true);
        POCKET_RADIUS = builder
                .comment("Radio (bloques) en el que el bolsillo magico absorbe objetos.")
                .defineInRange("pocketRadius", 6, 2, 16);
        RIDE_SPEED = builder
                .comment("Velocidad de vuelo montando la nube (0.05 es la de creativo).")
                .defineInRange("rideSpeed", 0.16D, 0.05D, 0.5D);
        builder.pop();

        SPEC = builder.build();
    }

    private AstralConfig() {}
}
