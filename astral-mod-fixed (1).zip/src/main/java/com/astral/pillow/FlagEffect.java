package com.astral.pillow;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Efecto "bandera" sin logica propia: sirve para que el cliente sepa que la almohada esta en uso (montando o descansando). */
public class FlagEffect extends MobEffect {
    public FlagEffect(int color) {
        super(MobEffectCategory.BENEFICIAL, color);
    }
}
