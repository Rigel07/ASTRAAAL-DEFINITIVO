package com.astral.pillow;

import com.astral.registry.ModEffects;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkHooks;

/** Acciones de la almohada que el jugador activa con las teclas (llegan por red como un numero). */
public final class PillowActions {
    public static final int SLEEP = 0;
    public static final int POCKET = 1;
    public static final int RIDE = 2;

    private static final int REST_TICKS = 100;

    private PillowActions() {}

    public static void perform(ServerPlayer player, int action) {
        switch (action) {
            case SLEEP -> {
                if (PillowUtil.worn(player, EquipmentSlot.CHEST)) {
                    startRest(player);
                } else {
                    player.displayClientMessage(Component.translatable("message.astral.pillow_need_chest"), true);
                }
            }
            case POCKET -> {
                ItemStack legs = player.getItemBySlot(EquipmentSlot.LEGS);
                if (PillowUtil.isPillow(legs)) {
                    openPocket(player, legs);
                } else {
                    player.displayClientMessage(Component.translatable("message.astral.pillow_need_legs"), true);
                }
            }
            case RIDE -> {
                if (PillowUtil.worn(player, EquipmentSlot.FEET)) {
                    toggleRide(player);
                } else {
                    player.displayClientMessage(Component.translatable("message.astral.pillow_need_feet"), true);
                }
            }
            default -> {
            }
        }
    }

    // ------------------------------------------------------------- bolsillo magico

    public static void openPocket(ServerPlayer player, ItemStack pillow) {
        UUID id = PillowUtil.ensureId(pillow);
        PocketInventory pocket = PocketStorage.get(player.server).pocket(id);
        NetworkHooks.openScreen(player, new SimpleMenuProvider(
                (windowId, inventory, p) -> new PocketMenu(windowId, inventory, pocket),
                Component.translatable("container.astral.pocket")));
        player.level().playSound(null, player.blockPosition(), SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 1.0F, 1.4F);
    }

    // ------------------------------------------------------------------ descanso

    public static void startRest(ServerPlayer player) {
        if (player.hasEffect(ModEffects.PILLOW_REST.get())) {
            return;
        }
        player.addEffect(new MobEffectInstance(ModEffects.PILLOW_REST.get(), REST_TICKS, 0, false, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, REST_TICKS, 6, false, false, false));
        player.displayClientMessage(Component.translatable("message.astral.pillow_resting"), true);
        player.level().playSound(null, player.blockPosition(), SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 1.0F, 0.8F);
    }

    /** Al terminar de descansar: se guarda el punto de reaparicion y, si la mayoria duerme, amanece. */
    public static void finishRest(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        player.setRespawnPosition(level.dimension(), player.blockPosition(), player.getYRot(), true, true);
        player.getStats().setValue(player, Stats.CUSTOM.get(Stats.TIME_SINCE_REST), 0);
        player.heal(player.getMaxHealth() * 0.5F);
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
        level.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.2D, player.getZ(), 8, 0.5D, 0.5D, 0.5D, 0.0D);
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.2F);

        long time = level.getDayTime() % 24000L;
        boolean night = time >= 12542L || level.isThundering();
        if (!night) {
            return;
        }
        int total = 0;
        int resting = 0;
        for (ServerPlayer other : level.players()) {
            if (other.isSpectator()) {
                continue;
            }
            total++;
            if (other == player || other.hasEffect(ModEffects.PILLOW_REST.get())) {
                resting++;
            }
        }
        if (total > 0 && resting * 2 >= total) {
            long now = level.getDayTime();
            level.setDayTime(now - now % 24000L + 24000L);
            level.setWeatherParameters(6000, 0, false, false);
            player.displayClientMessage(Component.translatable("message.astral.pillow_morning"), true);
        } else {
            player.displayClientMessage(Component.translatable("message.astral.pillow_waiting"), true);
        }
    }

    // ------------------------------------------------------------- montar la nube

    public static void toggleRide(ServerPlayer player) {
        if (player.hasEffect(ModEffects.PILLOW_RIDE.get())) {
            stopRide(player, true);
            return;
        }
        player.addEffect(new MobEffectInstance(ModEffects.PILLOW_RIDE.get(), 1_000_000, 0, false, false, false));
        player.setDeltaMovement(player.getDeltaMovement().x, 0.45D, player.getDeltaMovement().z);
        player.hurtMarked = true;
        player.displayClientMessage(Component.translatable("message.astral.pillow_ride_on"), true);
        ServerLevel level = player.serverLevel();
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.2F, 1.6F);
        level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(), 30, 0.6D, 0.1D, 0.6D, 0.05D);
    }

    public static void stopRide(ServerPlayer player, boolean message) {
        if (!player.hasEffect(ModEffects.PILLOW_RIDE.get())) {
            return;
        }
        player.removeEffect(ModEffects.PILLOW_RIDE.get());
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 120, 0, false, false, false));
        if (message) {
            player.displayClientMessage(Component.translatable("message.astral.pillow_ride_off"), true);
        }
        player.serverLevel().sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(),
                20, 0.5D, 0.1D, 0.5D, 0.03D);
    }
}
