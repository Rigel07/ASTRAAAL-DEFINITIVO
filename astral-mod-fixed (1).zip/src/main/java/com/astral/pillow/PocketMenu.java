package com.astral.pillow;

import com.astral.registry.ModMenus;
import javax.annotation.Nullable;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Menu del bolsillo magico: 6 filas como un cofre grande, con 3 paginas que se cambian con < y >. */
public class PocketMenu extends AbstractContainerMenu {
    public static final int ROWS = 6;
    public static final int PAGE_SIZE = ROWS * 9;
    public static final int PAGES = PocketInventory.SIZE / PAGE_SIZE;

    private final DataSlot pageSlot = DataSlot.standalone();
    @Nullable
    private final PageView view;

    /** Lado cliente: solo guarda la pagina que el servidor le envia. */
    public PocketMenu(int id, Inventory inventory) {
        this(id, inventory, new SimpleContainer(PAGE_SIZE), null);
    }

    /** Lado servidor: la pagina es una ventana sobre el bolsillo completo. */
    public PocketMenu(int id, Inventory inventory, PocketInventory pocket) {
        this(id, inventory, new PageView(pocket));
    }

    private PocketMenu(int id, Inventory inventory, PageView view) {
        this(id, inventory, view, view);
    }

    private PocketMenu(int id, Inventory inventory, Container container, @Nullable PageView view) {
        super(ModMenus.POCKET.get(), id);
        this.view = view;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(container, col + row * 9, 8 + col * 18, 18 + row * 18));
            }
        }
        int offset = (ROWS - 4) * 18;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 103 + row * 18 + offset));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inventory, col, 8 + col * 18, 161 + offset));
        }
        this.addDataSlot(this.pageSlot);
    }

    public int getPage() {
        return this.pageSlot.get();
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (this.view == null) {
            return false;
        }
        int page = this.view.page;
        if (id == 0) {
            page = Math.floorMod(page - 1, PAGES);
        } else if (id == 1) {
            page = Math.floorMod(page + 1, PAGES);
        } else {
            return false;
        }
        this.view.page = page;
        this.pageSlot.set(page);
        this.sendAllDataToRemote();
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < PAGE_SIZE) {
                if (!this.moveItemStackTo(stack, PAGE_SIZE, this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            } else if (!this.moveItemStackTo(stack, 0, PAGE_SIZE, false)) {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    /** Una pagina (54 huecos) del bolsillo completo. */
    private static class PageView implements Container {
        private final PocketInventory pocket;
        private int page;

        PageView(PocketInventory pocket) {
            this.pocket = pocket;
        }

        private int map(int slot) {
            return this.page * PAGE_SIZE + slot;
        }

        @Override
        public int getContainerSize() {
            return PAGE_SIZE;
        }

        @Override
        public boolean isEmpty() {
            return this.pocket.isEmpty();
        }

        @Override
        public ItemStack getItem(int slot) {
            return this.pocket.getItem(map(slot));
        }

        @Override
        public ItemStack removeItem(int slot, int amount) {
            return this.pocket.removeItem(map(slot), amount);
        }

        @Override
        public ItemStack removeItemNoUpdate(int slot) {
            return this.pocket.removeItemNoUpdate(map(slot));
        }

        @Override
        public void setItem(int slot, ItemStack stack) {
            this.pocket.setItem(map(slot), stack);
        }

        @Override
        public void setChanged() {
            this.pocket.setChanged();
        }

        @Override
        public boolean stillValid(Player player) {
            return true;
        }

        @Override
        public void clearContent() {
        }
    }
}
