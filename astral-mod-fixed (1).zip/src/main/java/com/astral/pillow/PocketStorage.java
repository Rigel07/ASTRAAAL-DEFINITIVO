package com.astral.pillow;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Todos los bolsillos magicos del mundo, guardados aparte de los objetos para no recargar la red. */
public class PocketStorage extends SavedData {
    private static final String ID = "astral_pockets";

    private final Map<UUID, PocketInventory> pockets = new HashMap<>();

    public static PocketStorage get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(PocketStorage::load, PocketStorage::new, ID);
    }

    public PocketInventory pocket(UUID id) {
        return pockets.computeIfAbsent(id, key -> new PocketInventory(this::setDirty));
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, PocketInventory> entry : pockets.entrySet()) {
            CompoundTag pocketTag = entry.getValue().save();
            pocketTag.putUUID("Id", entry.getKey());
            list.add(pocketTag);
        }
        tag.put("Pockets", list);
        return tag;
    }

    public static PocketStorage load(CompoundTag tag) {
        PocketStorage storage = new PocketStorage();
        ListTag list = tag.getList("Pockets", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag pocketTag = list.getCompound(i);
            PocketInventory inventory = new PocketInventory(storage::setDirty);
            inventory.load(pocketTag);
            storage.pockets.put(pocketTag.getUUID("Id"), inventory);
        }
        return storage;
    }
}
