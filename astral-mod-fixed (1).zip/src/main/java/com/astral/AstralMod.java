package com.astral;

import com.astral.registry.ModBlocks;
import com.astral.registry.ModCreativeTabs;
import com.astral.registry.ModEffects;
import com.astral.registry.ModEntities;
import com.astral.registry.ModItems;
import com.astral.config.AstralConfig;
import com.astral.registry.ModMenus;
import com.astral.registry.ModSounds;
import com.astral.pillow.PillowNetwork;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AstralMod.MODID)
public class AstralMod {
    public static final String MODID = "astral";

    public AstralMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModEffects.EFFECTS.register(modBus);
        ModMenus.MENUS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, AstralConfig.SPEC);
        ModCreativeTabs.TABS.register(modBus);
        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(PillowNetwork::register);
    }
}
