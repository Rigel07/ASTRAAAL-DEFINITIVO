package com.astral.block;

import com.astral.registry.ModSounds;
import com.astral.wish.AltarData;
import com.astral.wish.WishKind;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Altar de Deseos: deja una esencia dentro (clic derecho) y su poder se queda contigo, estes donde estes,
 * hasta que vuelvas a hacer clic en el altar para retirarla. Solo su dueno (o un operador) puede retirarla.
 */
public class WishAltarBlock extends Block {
    /** 0 = vacio; 1 a 11 = esencia dentro (orden del deseo + 1). */
    public static final IntegerProperty ESSENCE = IntegerProperty.create("essence", 0, WishKind.values().length);

    private static final VoxelShape SHAPE = Shapes.or(
            Block.box(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D),
            Block.box(3.0D, 2.0D, 3.0D, 13.0D, 7.0D, 13.0D),
            Block.box(0.0D, 7.0D, 0.0D, 16.0D, 8.0D, 16.0D));

    public WishAltarBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(ESSENCE, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ESSENCE);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        int stored = state.getValue(ESSENCE);

        if (stored == 0) {
            WishKind kind = WishKind.fromEssence(held.getItem());
            if (kind == null) {
                if (!level.isClientSide) {
                    player.displayClientMessage(Component.translatable("message.astral.altar_hint"), true);
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
            if (!(level instanceof ServerLevel serverLevel)) {
                return InteractionResult.SUCCESS;
            }
            if (!player.getAbilities().instabuild) {
                held.shrink(1);
            }
            serverLevel.setBlock(pos, state.setValue(ESSENCE, kind.ordinal() + 1), 3);
            AltarData.get(serverLevel.getServer()).put(player.getUUID(), player.getGameProfile().getName(),
                    kind.ordinal(), serverLevel.dimension(), pos);
            player.addEffect(new MobEffectInstance(kind.effect(), AltarData.ALTAR_DURATION, 0, false, true, true));

            serverLevel.playSound(null, pos, ModSounds.ALTAR_SUMMON.get(), SoundSource.BLOCKS, 1.4F, 1.0F);
            DustParticleOptions dust = new DustParticleOptions(kind.color(0), 1.6F);
            for (int i = 0; i < 24; i++) {
                serverLevel.sendParticles(dust, pos.getX() + 0.5D, pos.getY() + 1.0D + i * 0.2D, pos.getZ() + 0.5D,
                        2, 0.15D, 0.05D, 0.15D, 0.0D);
            }
            serverLevel.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                    20, 0.3D, 0.1D, 0.3D, 0.08D);
            player.displayClientMessage(Component.translatable("message.astral.altar_placed",
                    Component.translatable("wish.astral." + kind.id())), true);
            return InteractionResult.CONSUME;
        }

        // el altar ya tiene una esencia: solo su dueno (o un operador) puede retirarla
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }
        AltarData data = AltarData.get(serverLevel.getServer());
        AltarData.Entry entry = data.at(serverLevel.dimension(), pos);
        boolean allowed = entry == null || entry.owner().equals(player.getUUID()) || player.hasPermissions(2);
        if (!allowed) {
            player.displayClientMessage(Component.translatable("message.astral.altar_not_owner", entry.ownerName()), true);
            return InteractionResult.CONSUME;
        }
        release(serverLevel, pos, state, player);
        serverLevel.setBlock(pos, state.setValue(ESSENCE, 0), 3);
        serverLevel.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.BLOCKS, 1.2F, 0.8F);
        player.displayClientMessage(Component.translatable("message.astral.altar_removed",
                Component.translatable("wish.astral." + WishKind.byOrdinal(stored - 1).id())), true);
        return InteractionResult.CONSUME;
    }

    /** Devuelve la esencia (a quien la retira, o al suelo), borra el registro y apaga el poder de su dueno. */
    private static void release(ServerLevel level, BlockPos pos, BlockState state, Player giveTo) {
        int stored = state.getValue(ESSENCE);
        if (stored <= 0) {
            return;
        }
        WishKind kind = WishKind.byOrdinal(stored - 1);
        AltarData data = AltarData.get(level.getServer());
        AltarData.Entry entry = data.remove(level.dimension(), pos);

        ItemStack stack = new ItemStack(kind.essence());
        if (giveTo != null) {
            if (!giveTo.getInventory().add(stack)) {
                giveTo.drop(stack, false);
            }
        } else {
            Block.popResource(level, pos, stack);
        }

        if (entry != null && !data.owns(entry.owner(), kind.ordinal())) {
            Player owner = level.getServer().getPlayerList().getPlayer(entry.owner());
            if (owner != null) {
                owner.removeEffect(kind.effect());
            }
        }
    }

    /** Si rompen el altar (o lo explotan) con una esencia dentro, esta se suelta y el poder se apaga. */
    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock()) && state.getValue(ESSENCE) > 0 && level instanceof ServerLevel serverLevel) {
            release(serverLevel, pos, state, null);
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        int stored = state.getValue(ESSENCE);
        if (stored > 0) {
            WishKind kind = WishKind.byOrdinal(stored - 1);
            DustParticleOptions dust = new DustParticleOptions(kind.color((int) level.getGameTime()), 1.3F);
            for (int i = 0; i < 2; i++) {
                level.addParticle(dust,
                        pos.getX() + 0.25D + random.nextDouble() * 0.5D, pos.getY() + 0.9D + random.nextDouble() * 0.4D,
                        pos.getZ() + 0.25D + random.nextDouble() * 0.5D, 0.0D, 0.03D, 0.0D);
            }
        }
        if (random.nextInt(6) == 0) {
            level.addParticle(ParticleTypes.END_ROD,
                    pos.getX() + 0.3D + random.nextDouble() * 0.4D, pos.getY() + 0.7D,
                    pos.getZ() + 0.3D + random.nextDouble() * 0.4D, 0.0D, 0.03D, 0.0D);
        }
    }
}
