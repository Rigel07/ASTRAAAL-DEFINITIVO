package com.astral.wish;

import java.util.ArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;

/** El poder que concede un deseo: atributos permanentes mientras dura mas una habilidad que late cada segundo. */
public class WishEffect extends MobEffect {
    private final WishKind kind;

    public WishEffect(WishKind kind, int color) {
        super(MobEffectCategory.BENEFICIAL, color);
        this.kind = kind;
        AttributeModifier.Operation add = AttributeModifier.Operation.ADDITION;
        AttributeModifier.Operation mult = AttributeModifier.Operation.MULTIPLY_TOTAL;
        switch (kind) {
            case GREEN -> this.addAttributeModifier(Attributes.MAX_HEALTH, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a01", 8.0D, add);
            case RED -> {
                this.addAttributeModifier(Attributes.ATTACK_DAMAGE, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a02", 4.0D, add);
                this.addAttributeModifier(Attributes.ARMOR, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a03", 4.0D, add);
                this.addAttributeModifier(Attributes.KNOCKBACK_RESISTANCE, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a04", 0.5D, add);
            }
            case YELLOW -> {
                this.addAttributeModifier(Attributes.MOVEMENT_SPEED, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a05", 0.5D, mult);
                this.addAttributeModifier(Attributes.ATTACK_SPEED, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a06", 0.5D, mult);
            }
            case VIOLET -> {
                this.addAttributeModifier(Attributes.LUCK, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a07", 1.0D, add);
                this.addAttributeModifier(Attributes.MOVEMENT_SPEED, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a08", 0.15D, mult);
            }
            case GOLD -> {
                this.addAttributeModifier(Attributes.MAX_HEALTH, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a09", 20.0D, add);
                this.addAttributeModifier(Attributes.ATTACK_DAMAGE, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a0a", 6.0D, add);
                this.addAttributeModifier(Attributes.ARMOR, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a0b", 8.0D, add);
                this.addAttributeModifier(Attributes.ARMOR_TOUGHNESS, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a0c", 4.0D, add);
                this.addAttributeModifier(Attributes.LUCK, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a0d", 3.0D, add);
                this.addAttributeModifier(Attributes.MOVEMENT_SPEED, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a0e", 0.2D, mult);
                this.addAttributeModifier(Attributes.KNOCKBACK_RESISTANCE, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a0f", 0.5D, add);
            }
            case DARK -> {
                this.addAttributeModifier(Attributes.ATTACK_DAMAGE, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a10", 9.0D, add);
                this.addAttributeModifier(Attributes.ATTACK_SPEED, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a11", 0.4D, mult);
                this.addAttributeModifier(Attributes.MOVEMENT_SPEED, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a12", 0.3D, mult);
                this.addAttributeModifier(Attributes.MAX_HEALTH, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a13", -8.0D, add);
                this.addAttributeModifier(Attributes.ARMOR, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a14", 4.0D, add);
            }
            case BLUE -> this.addAttributeModifier(Attributes.MAX_HEALTH, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a15", 4.0D, add);
            case WHITE -> {
                this.addAttributeModifier(Attributes.KNOCKBACK_RESISTANCE, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a16", 0.3D, add);
                this.addAttributeModifier(Attributes.ARMOR, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a17", 3.0D, add);
            }
            case PINK -> {
                this.addAttributeModifier(Attributes.MAX_HEALTH, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a18", 4.0D, add);
                this.addAttributeModifier(Attributes.LUCK, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a19", 2.0D, add);
            }
            case ORANGE -> {
                this.addAttributeModifier(Attributes.ATTACK_DAMAGE, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a1a", 2.0D, add);
                this.addAttributeModifier(Attributes.LUCK, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a1b", 2.0D, add);
            }
            case RAINBOW -> {
                this.addAttributeModifier(Attributes.MAX_HEALTH, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a1c", 8.0D, add);
                this.addAttributeModifier(Attributes.ATTACK_DAMAGE, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a1d", 3.0D, add);
                this.addAttributeModifier(Attributes.ARMOR, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a1e", 4.0D, add);
                this.addAttributeModifier(Attributes.LUCK, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a1f", 3.0D, add);
                this.addAttributeModifier(Attributes.MOVEMENT_SPEED, "6a1c3e10-0b2d-4e61-9a55-1c0d7e2b3a20", 0.1D, mult);
            }
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration % 20 == 0;
    }

    @Override
    public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributes, int amplifier) {
        super.removeAttributeModifiers(entity, attributes, amplifier);
        // Si el efecto sigue activo, solo se esta renovando (los altares lo renuevan cada pocos segundos):
        // no hay que recortar la vida, o se perderian corazones sin motivo.
        if (!entity.hasEffect(this) && entity.getHealth() > entity.getMaxHealth()) {
            entity.setHealth(entity.getMaxHealth());
        }
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (!(entity.level() instanceof ServerLevel level)) {
            return;
        }
        switch (this.kind) {
            case GREEN -> tickGreen(level, entity);
            case RED -> tickRed(level, entity);
            case YELLOW -> tickYellow(level, entity);
            case VIOLET -> tickViolet(level, entity);
            case GOLD -> tickGold(level, entity);
            case DARK -> tickDark(level, entity);
            case BLUE -> tickBlue(level, entity);
            case WHITE -> tickWhite(level, entity);
            case PINK -> tickPink(level, entity);
            case ORANGE -> tickOrange(level, entity);
            case RAINBOW -> tickRainbow(level, entity);
        }
    }

    private static void dust(ServerLevel level, LivingEntity entity, WishKind kind, int count, double spread) {
        level.sendParticles(new DustParticleOptions(kind.color(entity.tickCount), 1.2F),
                entity.getX(), entity.getY() + 1.0D, entity.getZ(), count, spread, 0.7D, spread, 0.01D);
    }

    /** Verde: regenera, hace crecer los cultivos cercanos y cuida a los animales. */
    private static void tickGreen(ServerLevel level, LivingEntity entity) {
        entity.heal(2.0F);
        entity.removeEffect(MobEffects.POISON);
        entity.removeEffect(MobEffects.HUNGER);
        entity.removeEffect(MobEffects.WITHER);
        if (entity instanceof Player player) {
            player.getFoodData().eat(1, 0.2F);
        }
        BlockPos center = entity.blockPosition();
        for (int i = 0; i < 6; i++) {
            BlockPos pos = center.offset(level.random.nextInt(11) - 5, level.random.nextInt(3) - 1, level.random.nextInt(11) - 5);
            BlockState state = level.getBlockState(pos);
            if (state.getBlock() instanceof CropBlock crop && !crop.isMaxAge(state)) {
                crop.growCrops(level, pos, state);
            }
        }
        for (Animal animal : level.getEntitiesOfClass(Animal.class, entity.getBoundingBox().inflate(6.0D), Animal::isAlive)) {
            animal.heal(1.0F);
        }
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                6, 0.6D, 0.6D, 0.6D, 0.0D);
        dust(level, entity, WishKind.GREEN, 6, 0.5D);
    }

    /** Rojo: inmune al fuego y con un aura que prende fuego a los enemigos cercanos. */
    private static void tickRed(ServerLevel level, LivingEntity entity) {
        entity.clearFire();
        for (LivingEntity other : level.getEntitiesOfClass(LivingEntity.class, entity.getBoundingBox().inflate(3.5D),
                e -> e != entity && e instanceof Enemy && e.isAlive())) {
            other.setSecondsOnFire(4);
        }
        level.sendParticles(ParticleTypes.FLAME, entity.getX(), entity.getY() + 0.3D, entity.getZ(),
                10, 1.2D, 0.2D, 1.2D, 0.01D);
        dust(level, entity, WishKind.RED, 6, 0.5D);
    }

    /** Amarillo: ve en la oscuridad, salta alto y deja luz por donde pasa (ver AstralEvents). */
    private static void tickYellow(ServerLevel level, LivingEntity entity) {
        entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        entity.addEffect(new MobEffectInstance(MobEffects.JUMP, 60, 1, false, false, false));
        level.sendParticles(ParticleTypes.GLOW, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                4, 0.5D, 0.6D, 0.5D, 0.0D);
        dust(level, entity, WishKind.YELLOW, 6, 0.5D);
    }

    /** Violeta: caida lenta, saltos enormes y un radar que hace brillar a todos los seres vivos cercanos. */
    private static void tickViolet(ServerLevel level, LivingEntity entity) {
        entity.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 60, 0, false, false, false));
        entity.addEffect(new MobEffectInstance(MobEffects.JUMP, 60, 2, false, false, false));
        for (LivingEntity other : level.getEntitiesOfClass(LivingEntity.class, entity.getBoundingBox().inflate(24.0D),
                e -> e != entity && e.isAlive())) {
            other.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false, false));
        }
        level.sendParticles(ParticleTypes.ENCHANT, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                10, 0.6D, 0.8D, 0.6D, 0.1D);
        dust(level, entity, WishKind.VIOLET, 6, 0.5D);
    }

    /** Dorado: regeneracion, limpia efectos malos y alimenta; ademas de grandes atributos. */
    private static void tickGold(ServerLevel level, LivingEntity entity) {
        entity.heal(2.0F);
        for (MobEffectInstance instance : new ArrayList<>(entity.getActiveEffects())) {
            if (instance.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                entity.removeEffect(instance.getEffect());
            }
        }
        if (entity instanceof Player player) {
            player.getFoodData().eat(1, 0.3F);
        }
        level.sendParticles(ParticleTypes.END_ROD, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                6, 0.4D, 0.8D, 0.4D, 0.03D);
        dust(level, entity, WishKind.GOLD, 10, 0.6D);
    }

    /** Oscuro: mucho dano y velocidad a cambio de vida; frena a quien se acerca (el robo de vida esta en AstralEvents). */
    private static void tickDark(ServerLevel level, LivingEntity entity) {
        entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        for (LivingEntity other : level.getEntitiesOfClass(LivingEntity.class, entity.getBoundingBox().inflate(4.0D),
                e -> e != entity && !(e instanceof Player) && e.isAlive())) {
            other.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1, false, false, false));
        }
        level.sendParticles(ParticleTypes.SQUID_INK, entity.getX(), entity.getY() + 0.8D, entity.getZ(),
                8, 0.6D, 0.6D, 0.6D, 0.02D);
        level.sendParticles(ParticleTypes.SOUL, entity.getX(), entity.getY() + 0.5D, entity.getZ(),
                3, 0.5D, 0.4D, 0.5D, 0.02D);
        dust(level, entity, WishKind.DARK, 8, 0.6D);
    }

    /** Azul (oceano): respira bajo el agua, nada como un delfin y se cura con el agua y la lluvia. */
    private static void tickBlue(ServerLevel level, LivingEntity entity) {
        entity.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 400, 0, false, false, false));
        entity.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 100, 0, false, false, false));
        entity.addEffect(new MobEffectInstance(MobEffects.CONDUIT_POWER, 100, 0, false, false, false));
        entity.clearFire();
        if (entity.isInWaterOrRain()) {
            entity.heal(2.0F);
        }
        level.sendParticles(ParticleTypes.BUBBLE_POP, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                8, 0.5D, 0.7D, 0.5D, 0.02D);
        level.sendParticles(ParticleTypes.DRIPPING_WATER, entity.getX(), entity.getY() + 1.8D, entity.getZ(),
                4, 0.4D, 0.1D, 0.4D, 0.0D);
        dust(level, entity, WishKind.BLUE, 6, 0.5D);
    }

    /** Blanco (escarcha): congela a los enemigos cercanos (y camina sobre el agua, ver AstralEvents). */
    private static void tickWhite(ServerLevel level, LivingEntity entity) {
        entity.setTicksFrozen(0);
        for (LivingEntity other : level.getEntitiesOfClass(LivingEntity.class, entity.getBoundingBox().inflate(5.0D),
                e -> e != entity && e instanceof Enemy && e.isAlive())) {
            other.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2, false, false, false));
            other.setTicksFrozen(Math.min(other.getTicksRequiredToFreeze() + 40, other.getTicksFrozen() + 60));
        }
        level.sendParticles(ParticleTypes.SNOWFLAKE, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                14, 1.5D, 0.8D, 1.5D, 0.02D);
        dust(level, entity, WishKind.WHITE, 6, 0.5D);
    }

    /** Rosa (ternura): los animales cercanos se enamoran y crian, cura a aliados y mascotas y debilita a los enemigos. */
    private static void tickPink(ServerLevel level, LivingEntity entity) {
        entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 120, 1, false, false, false));
        for (Animal animal : level.getEntitiesOfClass(Animal.class, entity.getBoundingBox().inflate(10.0D), Animal::isAlive)) {
            if (animal.getAge() == 0 && animal.canFallInLove()) {
                animal.setInLove(entity instanceof Player player ? player : null);
            }
        }
        for (LivingEntity other : level.getEntitiesOfClass(LivingEntity.class, entity.getBoundingBox().inflate(8.0D),
                e -> e != entity && e.isAlive())) {
            if (other instanceof Player || (other instanceof TamableAnimal pet && pet.isTame())) {
                other.heal(2.0F);
            } else if (other instanceof Enemy && other.distanceToSqr(entity) < 36.0D) {
                other.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1, false, false, false));
            }
        }
        entity.heal(1.0F);
        level.sendParticles(ParticleTypes.HEART, entity.getX(), entity.getY() + 1.4D, entity.getZ(),
                4, 0.6D, 0.5D, 0.6D, 0.0D);
        dust(level, entity, WishKind.PINK, 6, 0.5D);
    }

    /** Naranja (minero): excava muy rapido, mira en la oscuridad y a veces duplica lo que sacas de un bloque (ver AstralEvents). */
    private static void tickOrange(ServerLevel level, LivingEntity entity) {
        entity.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 60, 2, false, false, false));
        entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        entity.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 60, 0, false, false, false));
        level.sendParticles(ParticleTypes.FALLING_LAVA, entity.getX(), entity.getY() + 1.6D, entity.getZ(),
                3, 0.4D, 0.1D, 0.4D, 0.0D);
        level.sendParticles(ParticleTypes.FLAME, entity.getX(), entity.getY() + 0.4D, entity.getZ(),
                4, 0.5D, 0.2D, 0.5D, 0.01D);
        dust(level, entity, WishKind.ORANGE, 6, 0.5D);
    }

    /** Arcoiris: cura, brilla en todos los colores y suma sus propios atributos (mas tres poderes al azar al recibirlo). */
    private static void tickRainbow(ServerLevel level, LivingEntity entity) {
        entity.heal(2.0F);
        entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        for (int i = 0; i < 4; i++) {
            dust(level, entity, WishKind.RAINBOW, 5, 0.6D);
        }
        level.sendParticles(ParticleTypes.END_ROD, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                8, 0.5D, 0.9D, 0.5D, 0.04D);
    }
}
