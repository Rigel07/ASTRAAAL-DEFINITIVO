package com.astral.wish;

import com.astral.block.WishAltarBlock;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Registro (guardado en el mundo) de los altares con una esencia dentro: quien la dejo, de que deseo es y donde esta.
 * Mientras el altar siga ocupado, su dueno conserva el poder del deseo, este donde este.
 */
public class AltarData extends SavedData {
    public record Entry(UUID owner, String ownerName, int kind, ResourceKey<Level> dim, BlockPos pos) {}

    private static final String NAME = "astral_altars";
    /** Duracion de los poderes de altar: practicamente infinita (unas 14 horas), se renueva mucho antes de acabarse. */
    public static final int ALTAR_DURATION = 1_000_000;
    private static final int REFRESH_BELOW = 600_000;
    /** Un poder normal de deseo nunca pasa de esto; si dura mas, lo puso un altar. */
    private static final int ALTAR_EFFECT_ABOVE = 450_000;

    private final Map<String, Entry> entries = new HashMap<>();

    public static AltarData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(AltarData::load, AltarData::new, NAME);
    }

    private static String key(ResourceKey<Level> dim, BlockPos pos) {
        return dim.location() + "|" + pos.asLong();
    }

    public void put(UUID owner, String ownerName, int kind, ResourceKey<Level> dim, BlockPos pos) {
        BlockPos fixed = pos.immutable();
        this.entries.put(key(dim, fixed), new Entry(owner, ownerName, kind, dim, fixed));
        this.setDirty();
    }

    public Entry at(ResourceKey<Level> dim, BlockPos pos) {
        return this.entries.get(key(dim, pos));
    }

    public Entry remove(ResourceKey<Level> dim, BlockPos pos) {
        Entry removed = this.entries.remove(key(dim, pos));
        if (removed != null) {
            this.setDirty();
        }
        return removed;
    }

    /** Si el jugador aun tiene algun altar ocupado con esa esencia. */
    public boolean owns(UUID owner, int kind) {
        for (Entry entry : this.entries.values()) {
            if (entry.owner().equals(owner) && entry.kind() == kind) {
                return true;
            }
        }
        return false;
    }

    /** Cada segundo: renueva los poderes de los altares del jugador y limpia los altares que ya no existen. */
    public void tick(ServerPlayer player) {
        // si un altar ya no existe (se rompio con el dueno desconectado), su poder se apaga al volver
        for (WishKind kind : WishKind.values()) {
            MobEffectInstance active = player.getEffect(kind.effect());
            if (active != null && active.getDuration() > ALTAR_EFFECT_ABOVE && !this.owns(player.getUUID(), kind.ordinal())) {
                player.removeEffect(kind.effect());
            }
        }
        for (Entry entry : new ArrayList<>(this.entries.values())) {
            if (!entry.owner().equals(player.getUUID())) {
                continue;
            }
            ServerLevel level = player.server.getLevel(entry.dim());
            if (level == null) {
                this.remove(entry.dim(), entry.pos());
                continue;
            }
            if (level.hasChunkAt(entry.pos()) && !(level.getBlockState(entry.pos()).getBlock() instanceof WishAltarBlock)) {
                this.remove(entry.dim(), entry.pos());
                continue;
            }
            MobEffect effect = WishKind.byOrdinal(entry.kind()).effect();
            MobEffectInstance current = player.getEffect(effect);
            if (current == null || current.getDuration() < REFRESH_BELOW) {
                player.addEffect(new MobEffectInstance(effect, ALTAR_DURATION, 0, false, true, true));
            }
        }
    }

    public static AltarData load(CompoundTag tag) {
        AltarData data = new AltarData();
        ListTag list = tag.getList("Altars", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag item = list.getCompound(i);
            ResourceKey<Level> dim = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(item.getString("Dim")));
            BlockPos pos = BlockPos.of(item.getLong("Pos"));
            data.entries.put(key(dim, pos),
                    new Entry(item.getUUID("Owner"), item.getString("Name"), item.getInt("Kind"), dim, pos));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Entry entry : this.entries.values()) {
            CompoundTag item = new CompoundTag();
            item.putUUID("Owner", entry.owner());
            item.putString("Name", entry.ownerName());
            item.putInt("Kind", entry.kind());
            item.putString("Dim", entry.dim().location().toString());
            item.putLong("Pos", entry.pos().asLong());
            list.add(item);
        }
        tag.put("Altars", list);
        return tag;
    }
}
