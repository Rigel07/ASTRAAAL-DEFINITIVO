package com.astral.wish;

import com.astral.AstralMod;
import com.astral.block.AstralLightBlock;
import com.astral.item.CometHammerItem;
import com.astral.registry.ModEffects;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/** Efectos que dependen de eventos: golpes, muertes, bloques, proyectiles, experiencia, estelas y combos de deseos. */
@Mod.EventBusSubscriber(modid = AstralMod.MODID)
public final class AstralEvents {
    private AstralEvents() {}

    /** Poderes que se activan al golpear: robo de vida oscuro, fuego rojo, chispas amarillas y escarcha blanca. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        LivingEntity target = event.getEntity();
        if (target.level().isClientSide()) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker) || attacker == target) {
            return;
        }
        // Pacto oscuro: cura el 30 % del dano que inflige
        if (attacker.hasEffect(ModEffects.DARK.get())) {
            attacker.heal(event.getAmount() * 0.3F);
        }
        // Rojo: lo que golpeas arde
        if (attacker.hasEffect(ModEffects.RED.get())) {
            target.setSecondsOnFire(5);
        }
        // Blanco: lo que golpeas se congela y se frena
        if (attacker.hasEffect(ModEffects.WHITE.get())) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2, false, false, false));
            target.setTicksFrozen(Math.min(target.getTicksRequiredToFreeze() + 60, target.getTicksFrozen() + 80));
        }
        // Amarillo: 15 % de que la descarga salte a otros dos enemigos cercanos
        if (attacker.hasEffect(ModEffects.YELLOW.get()) && target.level() instanceof ServerLevel level
                && level.random.nextFloat() < 0.15F) {
            int arcs = 0;
            List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class, target.getBoundingBox().inflate(5.0D),
                    e -> e != target && e != attacker && e instanceof Enemy && e.isAlive());
            for (LivingEntity other : near) {
                if (arcs >= 2) {
                    break;
                }
                other.hurt(level.damageSources().lightningBolt(), Math.max(2.0F, event.getAmount() * 0.5F));
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, other.getX(), other.getY() + 1.0D, other.getZ(),
                        14, 0.3D, 0.5D, 0.3D, 0.2D);
                arcs++;
            }
        }
    }

    /** Oscuro: cada muerte que provocas te cura 2 corazones. */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide()) {
            return;
        }
        if (event.getSource().getEntity() instanceof LivingEntity killer && killer != event.getEntity()
                && killer.hasEffect(ModEffects.DARK.get())) {
            killer.heal(4.0F);
        }
    }

    /** Dorado y arcoiris: el doble de experiencia por cada criatura que derrotas. */
    @SubscribeEvent
    public static void onExperience(LivingExperienceDropEvent event) {
        Player killer = event.getAttackingPlayer();
        if (killer != null && (killer.hasEffect(ModEffects.GOLD.get()) || killer.hasEffect(ModEffects.RAINBOW.get()))) {
            event.setDroppedExperience(event.getDroppedExperience() * 2);
        }
    }

    /** Violeta: 35 % de esquivar flechas y demas proyectiles. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide() || !victim.hasEffect(ModEffects.VIOLET.get())
                || !event.getSource().is(DamageTypeTags.IS_PROJECTILE)) {
            return;
        }
        if (victim.level() instanceof ServerLevel level && level.random.nextFloat() < 0.35F) {
            event.setCanceled(true);
            level.sendParticles(ParticleTypes.PORTAL, victim.getX(), victim.getY() + 1.0D, victim.getZ(),
                    20, 0.4D, 0.8D, 0.4D, 0.3D);
        }
    }

    /** Naranja y arcoiris: 30 % de duplicar lo que suelta un bloque que rompes con la herramienta correcta. */
    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        Player player = event.getPlayer();
        if (player == null || player.isCreative() || !(event.getLevel() instanceof ServerLevel level)
                || !(player.hasEffect(ModEffects.ORANGE.get()) || player.hasEffect(ModEffects.RAINBOW.get()))) {
            return;
        }
        BlockState state = event.getState();
        BlockPos pos = event.getPos();
        if (level.random.nextFloat() >= 0.30F || level.getBlockEntity(pos) != null
                || !player.hasCorrectToolForDrops(state)) {
            return;
        }
        for (ItemStack drop : Block.getDrops(state, level, pos, null, player, player.getMainHandItem())) {
            Block.popResource(level, pos, drop);
        }
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                6, 0.3D, 0.3D, 0.3D, 0.0D);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER
                || event.player.tickCount % 4 != 0) {
            return;
        }
        Player player = event.player;
        Level level = player.level();

        // Amarillo y dorado: dejan una estela de luz por donde pasan
        boolean gold = player.hasEffect(ModEffects.GOLD.get());
        if (gold || player.hasEffect(ModEffects.YELLOW.get())) {
            BlockPos pos = player.blockPosition().above();
            if (!level.getBlockState(pos).isAir()) {
                pos = player.blockPosition();
            }
            AstralLightBlock.place(level, pos, gold ? 14 : 11);
        }

        // Blanco: camina sobre el agua congelandola
        if (player.hasEffect(ModEffects.WHITE.get())) {
            frostWalk(player, level);
        }

        // Armonia astral: cuantos mas deseos activos, mas bonificaciones
        if (player.tickCount % 20 == 0) {
            if (player instanceof ServerPlayer serverPlayer) {
                AltarData.get(serverPlayer.server).tick(serverPlayer);
            }
            harmony(player);
        }
    }

    private static void frostWalk(Player player, Level level) {
        BlockPos feet = player.blockPosition();
        BlockState frosted = Blocks.FROSTED_ICE.defaultBlockState();
        for (BlockPos pos : BlockPos.betweenClosed(feet.offset(-3, -1, -3), feet.offset(3, -1, 3))) {
            if (!pos.closerToCenterThan(player.position(), 3.5D) || !level.getBlockState(pos.above()).isAir()) {
                continue;
            }
            BlockState current = level.getBlockState(pos);
            if (current.is(Blocks.WATER) && current.getValue(LiquidBlock.LEVEL) == 0
                    && frosted.canSurvive(level, pos) && level.isUnobstructed(frosted, pos, CollisionContext.empty())) {
                level.setBlockAndUpdate(pos, frosted);
                level.scheduleTick(pos, Blocks.FROSTED_ICE, Mth.nextInt(level.getRandom(), 60, 120));
            }
        }
    }

    /** 2 deseos: escudo extra; 3: resistencia; 4 o mas: regeneracion y fuerza. */
    private static void harmony(Player player) {
        int count = 0;
        for (WishKind kind : WishKind.values()) {
            if (player.hasEffect(kind.effect())) {
                count++;
            }
        }
        if (count >= 2) {
            player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 60, 1, false, false, false));
        }
        if (count >= 3) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 0, false, false, false));
        }
        if (count >= 4) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 1, false, false, false));
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 0, false, false, false));
        }
    }

    /** Martillo del cometa: caer con el en la mano provoca un impacto en area y anula el dano de la caida. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide()) {
            return;
        }
        if (event.getDistance() > 3.0F && CometHammerItem.isHolding(player)) {
            CometHammerItem.slam(player, event.getDistance());
            event.setDamageMultiplier(0.0F);
        }
    }
}
