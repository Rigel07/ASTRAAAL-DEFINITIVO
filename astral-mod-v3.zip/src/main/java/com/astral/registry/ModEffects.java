package com.astral.registry;

import com.astral.AstralMod;
import com.astral.pillow.FlagEffect;
import com.astral.wish.WishEffect;
import com.astral.wish.WishKind;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Los poderes que concede cada deseo. */
public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, AstralMod.MODID);

    public static final RegistryObject<MobEffect> GREEN = EFFECTS.register("wish_green",
            () -> new WishEffect(WishKind.GREEN, 0x59FF73));
    public static final RegistryObject<MobEffect> RED = EFFECTS.register("wish_red",
            () -> new WishEffect(WishKind.RED, 0xFF4040));
    public static final RegistryObject<MobEffect> YELLOW = EFFECTS.register("wish_yellow",
            () -> new WishEffect(WishKind.YELLOW, 0xFFE64D));
    public static final RegistryObject<MobEffect> VIOLET = EFFECTS.register("wish_violet",
            () -> new WishEffect(WishKind.VIOLET, 0xB366FF));
    public static final RegistryObject<MobEffect> GOLD = EFFECTS.register("wish_gold",
            () -> new WishEffect(WishKind.GOLD, 0xFFC726));
    public static final RegistryObject<MobEffect> DARK = EFFECTS.register("wish_dark",
            () -> new WishEffect(WishKind.DARK, 0x59198A));

    public static final RegistryObject<MobEffect> BLUE = EFFECTS.register("wish_blue",
            () -> new WishEffect(WishKind.BLUE, 0x4DA6FF));
    public static final RegistryObject<MobEffect> WHITE = EFFECTS.register("wish_white",
            () -> new WishEffect(WishKind.WHITE, 0xEBF7FF));
    public static final RegistryObject<MobEffect> PINK = EFFECTS.register("wish_pink",
            () -> new WishEffect(WishKind.PINK, 0xFF8CC7));
    public static final RegistryObject<MobEffect> ORANGE = EFFECTS.register("wish_orange",
            () -> new WishEffect(WishKind.ORANGE, 0xFF8C26));
    public static final RegistryObject<MobEffect> RAINBOW = EFFECTS.register("wish_rainbow",
            () -> new WishEffect(WishKind.RAINBOW, 0xFFB3F0));

    /** Banderas sincronizadas con el cliente para dibujar la almohada (montando / descansando). */
    public static final RegistryObject<MobEffect> PILLOW_RIDE = EFFECTS.register("pillow_ride",
            () -> new FlagEffect(0xFFFFFF));
    public static final RegistryObject<MobEffect> PILLOW_REST = EFFECTS.register("pillow_rest",
            () -> new FlagEffect(0xFFC8E6));

    private ModEffects() {}
}
