package com.astral.registry;

import com.astral.AstralMod;
import com.astral.item.AstralArsenal;
import com.astral.item.CometHammerItem;
import com.astral.item.MagicPillowItem;
import com.astral.item.MoonBladeItem;
import com.astral.item.WishCompassItem;
import com.astral.item.StarStaffItem;
import com.astral.item.SunScepterItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AstralMod.MODID);

    // --- las cuatro armas del astral
    public static final RegistryObject<Item> STAR_STAFF = ITEMS.register("star_staff", StarStaffItem::new);
    public static final RegistryObject<Item> MOON_BLADE = ITEMS.register("moon_blade", MoonBladeItem::new);
    public static final RegistryObject<Item> SUN_SCEPTER = ITEMS.register("sun_scepter", SunScepterItem::new);
    public static final RegistryObject<Item> COURAGE_BLADE = ITEMS.register("courage_blade", AstralArsenal.CourageBlade::new);
    public static final RegistryObject<Item> DAWN_SPEAR = ITEMS.register("dawn_spear", AstralArsenal.DawnSpear::new);
    public static final RegistryObject<Item> ECLIPSE_SCYTHE = ITEMS.register("eclipse_scythe", AstralArsenal.EclipseScythe::new);
    public static final RegistryObject<Item> AEGIS_AXE = ITEMS.register("aegis_axe", AstralArsenal.AegisAxe::new);
    public static final RegistryObject<Item> FROST_SCEPTER = ITEMS.register("frost_scepter", AstralArsenal.FrostScepter::new);
    public static final RegistryObject<Item> GALE_DAGGER = ITEMS.register("gale_dagger", AstralArsenal.GaleDagger::new);
    public static final RegistryObject<Item> ARCANE_WAND = ITEMS.register("arcane_wand", AstralArsenal.ArcaneWand::new);
    public static final RegistryObject<Item> COMET_HAMMER = ITEMS.register("comet_hammer", CometHammerItem::new);

    // --- esencias que dejan los deseos que caen sin tocar a nadie
    public static final RegistryObject<Item> ESSENCE_GREEN = essence("wish_essence_green", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_RED = essence("wish_essence_red", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_YELLOW = essence("wish_essence_yellow", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_VIOLET = essence("wish_essence_violet", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_GOLD = essence("wish_essence_gold", Rarity.EPIC);
    public static final RegistryObject<Item> ESSENCE_DARK = essence("wish_essence_dark", Rarity.EPIC);

    public static final RegistryObject<Item> ESSENCE_BLUE = essence("wish_essence_blue", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_WHITE = essence("wish_essence_white", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_PINK = essence("wish_essence_pink", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_ORANGE = essence("wish_essence_orange", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_RAINBOW = essence("wish_essence_rainbow", Rarity.EPIC);

    public static final RegistryObject<Item> ESSENCE_CYAN = essence("wish_essence_cyan", Rarity.UNCOMMON);
    public static final RegistryObject<Item> ESSENCE_SILVER = essence("wish_essence_silver", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_LIME = essence("wish_essence_lime", Rarity.COMMON);
    public static final RegistryObject<Item> ESSENCE_MAGENTA = essence("wish_essence_magenta", Rarity.COMMON);

    /** Huevo para invocar Arcontes (pruebas y creativo). */
    public static final RegistryObject<Item> ARCHON_SPAWN_EGG = ITEMS.register("archon_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ARCHON, 0x2A1245, 0xA64DFF, new Item.Properties()));

    /** La almohada magica: se fabrica con las seis esencias y una lana. */
    public static final RegistryObject<Item> MAGIC_PILLOW = ITEMS.register("magic_pillow", MagicPillowItem::new);

    public static final RegistryObject<Item> WISH_ALTAR = ITEMS.register("wish_altar",
            () -> new BlockItem(ModBlocks.WISH_ALTAR.get(), new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> WISH_COMPASS = ITEMS.register("wish_compass", WishCompassItem::new);

    private ModItems() {}

    private static RegistryObject<Item> essence(String name, Rarity rarity) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().rarity(rarity)));
    }
}
