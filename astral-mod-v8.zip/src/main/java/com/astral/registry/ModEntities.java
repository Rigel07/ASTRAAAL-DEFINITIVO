package com.astral.registry;

import com.astral.AstralMod;
import com.astral.archon.ArchonEntity;
import com.astral.wish.WishEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AstralMod.MODID);

    public static final RegistryObject<EntityType<WishEntity>> WISH = ENTITY_TYPES.register("wish",
            () -> EntityType.Builder.<WishEntity>of(WishEntity::new, MobCategory.MISC)
                    .sized(0.6F, 0.6F)
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .fireImmune()
                    .noSave()
                    .build(AstralMod.MODID + ":wish"));

    public static final RegistryObject<EntityType<ArchonEntity>> ARCHON = ENTITY_TYPES.register("archon",
            () -> EntityType.Builder.<ArchonEntity>of(ArchonEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(10)
                    .build(AstralMod.MODID + ":archon"));

    private ModEntities() {}
}
