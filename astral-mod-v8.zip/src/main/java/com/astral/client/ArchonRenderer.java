package com.astral.client;

import com.astral.AstralMod;
import com.astral.archon.ArchonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Dibuja al Arconte como una figura alta y esbelta; su textura cambia con la forma de miedo que ha tomado. */
public class ArchonRenderer extends HumanoidMobRenderer<ArchonEntity, HumanoidModel<ArchonEntity>> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[ArchonEntity.Fear.values().length];

    static {
        for (ArchonEntity.Fear fear : ArchonEntity.Fear.values()) {
            TEXTURES[fear.ordinal()] = new ResourceLocation(AstralMod.MODID, "textures/entity/archon_" + fear.id() + ".png");
        }
    }

    public ArchonRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(ArchonEntity entity) {
        return TEXTURES[entity.getFear().ordinal()];
    }

    @Override
    protected void scale(ArchonEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.0F, 1.1F, 1.0F);
    }
}
