package com.astral.archon;

import com.astral.registry.ModEffects;
import java.util.Locale;
import javax.annotation.Nullable;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * Arconte: un ser que vive de asustarte. Toma la forma de tus miedos (oscuridad, altura, ahogo, fuego o veneno),
 * se teletransporta a tu espalda cuando no lo miras y se alimenta del terror de los jugadores cercanos.
 * Se debilita con la luz. El deseo de Coraje (cian) te hace inmune a su miedo y duplica el dano que le haces.
 */
public class ArchonEntity extends Monster {
    public enum Fear {
        SHADOW(0.35F, 0.12F, 0.55F),
        HEIGHTS(0.70F, 0.85F, 1.00F),
        DROWNING(0.15F, 0.55F, 0.80F),
        FLAME(1.00F, 0.40F, 0.10F),
        VENOM(0.35F, 0.85F, 0.20F);

        public final float r;
        public final float g;
        public final float b;

        Fear(float r, float g, float b) {
            this.r = r;
            this.g = g;
            this.b = b;
        }

        public String id() {
            return this.name().toLowerCase(Locale.ROOT);
        }

        public static Fear byIndex(int index) {
            Fear[] all = values();
            return all[Mth.clamp(index, 0, all.length - 1)];
        }
    }

    private static final EntityDataAccessor<Integer> FORM =
            SynchedEntityData.defineId(ArchonEntity.class, EntityDataSerializers.INT);

    private int morphTimer = 300;

    public ArchonEntity(EntityType<? extends ArchonEntity> type, Level level) {
        super(type, level);
        this.xpReward = 30;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 70.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.ATTACK_DAMAGE, 9.0D)
                .add(Attributes.ARMOR, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 12.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(FORM, 0);
    }

    public Fear getFear() {
        return Fear.byIndex(this.entityData.get(FORM));
    }

    public void setFear(Fear fear) {
        this.entityData.set(FORM, fear.ordinal());
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Form", this.getFear().ordinal());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setFear(Fear.byIndex(tag.getInt("Form")));
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData spawnData, @Nullable CompoundTag tag) {
        this.setFear(Fear.byIndex(this.random.nextInt(Fear.values().length)));
        return super.finalizeSpawn(level, difficulty, reason, spawnData, tag);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            if (this.random.nextInt(2) == 0) {
                Fear fear = this.getFear();
                this.level().addParticle(new DustParticleOptions(new Vector3f(fear.r, fear.g, fear.b), 1.2F),
                        this.getRandomX(0.6D), this.getRandomY(), this.getRandomZ(0.6D), 0.0D, 0.02D, 0.0D);
            }
            return;
        }
        if (!(this.level() instanceof ServerLevel server) || !this.isAlive()) {
            return;
        }
        this.morphTimer--;
        if (this.morphTimer <= 0) {
            this.morph(server);
        }
        if (this.tickCount % 20 == 0) {
            this.secondTick(server);
        }
    }

    /** Cambia a la forma que mas asusta al objetivo (agua, oscuridad...) o a una al azar. */
    private void morph(ServerLevel server) {
        Fear old = this.getFear();
        Fear next = old;
        LivingEntity target = this.getTarget();
        if (target != null && target.isInWater()) {
            next = Fear.DROWNING;
        } else if (target != null && server.getMaxLocalRawBrightness(target.blockPosition()) < 5) {
            next = Fear.SHADOW;
        }
        int guard = 0;
        while (next == old && guard++ < 10) {
            next = Fear.byIndex(this.random.nextInt(Fear.values().length));
        }
        this.setFear(next);
        server.sendParticles(ParticleTypes.SOUL, this.getX(), this.getY() + 1.0D, this.getZ(),
                15, 0.3D, 0.6D, 0.3D, 0.05D);
        this.playSound(SoundEvents.SOUL_ESCAPE, 1.0F, 0.7F);
        this.morphTimer = 200 + this.random.nextInt(300);
    }

    private void secondTick(ServerLevel server) {
        // la luz los quema
        if (server.getMaxLocalRawBrightness(this.blockPosition()) >= 12) {
            this.hurt(this.damageSources().magic(), 2.0F);
        }

        // se alimentan del terror de los jugadores cercanos (los valientes no sienten miedo)
        for (Player player : server.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(12.0D),
                p -> p.isAlive() && !p.isSpectator() && !p.isCreative())) {
            if (player.hasEffect(ModEffects.CYAN.get())) {
                continue;
            }
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, false, false));
            if (this.getFear() == Fear.SHADOW) {
                player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0, false, false, false));
            }
            this.heal(2.0F);
            if (this.random.nextInt(8) == 0) {
                player.displayClientMessage(Component.translatable("message.astral.archon_chill"), true);
            }
        }

        // aparece a tu espalda cuando no lo miras
        LivingEntity target = this.getTarget();
        if (target != null && this.distanceToSqr(target) > 36.0D && this.random.nextFloat() < 0.35F) {
            Vec3 look = target.getLookAngle().multiply(1.0D, 0.0D, 1.0D);
            if (look.lengthSqr() > 1.0E-4D) {
                look = look.normalize();
                Vec3 toMe = this.position().subtract(target.position()).multiply(1.0D, 0.0D, 1.0D);
                if (toMe.lengthSqr() > 1.0E-4D && look.dot(toMe.normalize()) < 0.3D) {
                    if (this.randomTeleport(target.getX() - look.x * 2.5D, target.getY(), target.getZ() - look.z * 2.5D, true)) {
                        this.playSound(SoundEvents.ENDERMAN_TELEPORT, 1.0F, 0.5F);
                    }
                }
            }
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity victim) {
            if (victim.hasEffect(ModEffects.CYAN.get())) {
                // el valor los hiere
                this.hurt(this.damageSources().magic(), 3.0F);
            } else {
                this.applyFear(victim);
                this.heal(4.0F);
            }
        }
        return hit;
    }

    private void applyFear(LivingEntity victim) {
        switch (this.getFear()) {
            case SHADOW -> {
                victim.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0));
                victim.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
            }
            case HEIGHTS -> victim.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 50, 1));
            case DROWNING -> {
                victim.setAirSupply(Math.max(-20, victim.getAirSupply() - 120));
                victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
            }
            case FLAME -> victim.setSecondsOnFire(6);
            case VENOM -> {
                victim.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
                victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 0));
            }
        }
    }

    /** A veces se esfuma al recibir un golpe y reaparece cerca. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !this.level().isClientSide && this.isAlive() && this.random.nextFloat() < 0.2F) {
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            this.randomTeleport(this.getX() + Math.cos(angle) * 6.0D, this.getY(), this.getZ() + Math.sin(angle) * 6.0D, true);
        }
        return hurt;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.PHANTOM_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PHANTOM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PHANTOM_DEATH;
    }
}
