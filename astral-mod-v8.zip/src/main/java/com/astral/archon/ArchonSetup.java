package com.astral.archon;

import com.astral.AstralMod;
import com.astral.registry.ModEntities;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Atributos y reglas de aparicion del Arconte (solo en oscuridad, como los monstruos normales). */
@Mod.EventBusSubscriber(modid = AstralMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ArchonSetup {
    private ArchonSetup() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.ARCHON.get(), ArchonEntity.createAttributes().build());
    }

    @SubscribeEvent
    public static void spawnRules(SpawnPlacementRegisterEvent event) {
        event.register(ModEntities.ARCHON.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.OR);
    }
}
