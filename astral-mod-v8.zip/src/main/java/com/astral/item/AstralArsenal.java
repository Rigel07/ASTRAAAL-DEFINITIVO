package com.astral.item;

import com.astral.block.AstralLightBlock;
import com.astral.registry.ModEffects;
import com.astral.wish.WishKind;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Armas nuevas, una por cada color de deseo. Todas son reliquias (indestructibles) con una habilidad de clic derecho,
 * y todas estan pensadas para enfrentarse a los Arcontes (y a cualquier otro enemigo hostil).
 */
public final class AstralArsenal {
    private AstralArsenal() {}

    private static InteractionResultHolder<ItemStack> done(Level level, ItemStack stack) {
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    private static void ring(ServerLevel level, Vec3 center, double radius, net.minecraft.core.particles.ParticleOptions particle) {
        for (int i = 0; i < 40; i++) {
            double angle = i * Math.PI * 2.0D / 40.0D;
            level.sendParticles(particle, center.x + Math.cos(angle) * radius, center.y + 0.4D,
                    center.z + Math.sin(angle) * radius, 1, 0.0D, 0.1D, 0.0D, 0.0D);
        }
    }

    /** Espada del Coraje (cian): Grito de Valor, da Coraje a los aliados cercanos y hiere a los enemigos, sobre todo Arcontes. */
    public static class CourageBlade extends AstralWeaponItem {
        public CourageBlade() {
            super("courage_blade", 7.0D, -2.4D);
        }

        @Override
        public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (target instanceof com.astral.archon.ArchonEntity) {
                target.hurt(target.damageSources().magic(), 5.0F);
            }
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level instanceof ServerLevel server) {
                for (Player ally : server.getEntitiesOfClass(Player.class, player.getBoundingBox().inflate(10.0D),
                        p -> p.isAlive() && !p.isSpectator())) {
                    ally.removeEffect(MobEffects.DARKNESS);
                    ally.removeEffect(MobEffects.BLINDNESS);
                    ally.removeEffect(MobEffects.LEVITATION);
                    ally.removeEffect(MobEffects.POISON);
                    ally.removeEffect(MobEffects.CONFUSION);
                    ally.addEffect(new MobEffectInstance(ModEffects.CYAN.get(), 400, 0, false, true, true));
                    server.sendParticles(ParticleTypes.ELECTRIC_SPARK, ally.getX(), ally.getY() + 1.0D, ally.getZ(),
                            20, 0.4D, 0.8D, 0.4D, 0.2D);
                }
                for (LivingEntity foe : foesAround(server, player, 10.0D)) {
                    strike(server, player, foe, 6.0F, 2.0F);
                    foe.knockback(0.9D, player.getX() - foe.getX(), player.getZ() - foe.getZ());
                }
                ring(server, player.position(), 9.0D, new DustParticleOptions(WishKind.CYAN.color(0), 1.6F));
                server.playSound(null, player.blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.0F, 1.6F);
                server.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0F, 1.4F);
            }
            player.getCooldowns().addCooldown(this, 600);
            return done(level, stack);
        }
    }

    /** Lanza del Alba (amarillo + dorado + cian): haz de luz que atraviesa a los enemigos; la luz destroza a los Arcontes. */
    public static class DawnSpear extends AstralWeaponItem {
        public DawnSpear() {
            super("dawn_spear", 6.0D, -2.6D);
        }

        @Override
        public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (target instanceof com.astral.archon.ArchonEntity) {
                target.hurt(target.damageSources().magic(), 4.0F);
            }
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level instanceof ServerLevel server) {
                Ray ray = castRay(server, player, 28.0D, 1.0D);
                for (LivingEntity foe : ray.foes()) {
                    strike(server, player, foe, 8.0F, 3.0F);
                    server.sendParticles(ParticleTypes.FLASH, foe.getX(), foe.getY() + 1.0D, foe.getZ(), 1, 0.0D, 0.0D, 0.0D, 0.0D);
                }
                Vec3 dir = ray.end().subtract(ray.start());
                double length = dir.length();
                if (length > 0.01D) {
                    dir = dir.normalize();
                    for (double d = 0.5D; d <= length; d += 0.5D) {
                        Vec3 p = ray.start().add(dir.scale(d));
                        server.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.05D, 0.05D, 0.05D, 0.0D);
                    }
                    for (double d = 2.0D; d <= length; d += 3.0D) {
                        BlockPos pos = BlockPos.containing(ray.start().add(dir.scale(d)));
                        if (server.getBlockState(pos).isAir()) {
                            AstralLightBlock.place(server, pos, 15);
                        }
                    }
                }
                server.playSound(null, player.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2F, 1.8F);
                server.playSound(null, player.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 0.4F, 2.0F);
            }
            player.getCooldowns().addCooldown(this, 160);
            return done(level, stack);
        }
    }

    /** Guadana del Eclipse (oscuro + violeta + cian): cada golpe te cura; Cosecha de Almas drena a los enemigos cercanos. */
    public static class EclipseScythe extends AstralWeaponItem {
        public EclipseScythe() {
            super("eclipse_scythe", 8.0D, -3.0D);
        }

        @Override
        public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            attacker.heal(target instanceof com.astral.archon.ArchonEntity ? 6.0F : 3.0F);
            if (target.level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.SOUL, target.getX(), target.getY() + 1.0D, target.getZ(), 6, 0.3D, 0.5D, 0.3D, 0.05D);
            }
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level instanceof ServerLevel server) {
                List<LivingEntity> foes = foesAround(server, player, 7.0D);
                if (foes.isEmpty()) {
                    return InteractionResultHolder.pass(stack);
                }
                float healed = 0.0F;
                for (LivingEntity foe : foes) {
                    strike(server, player, foe, 6.0F, 2.0F);
                    healed += foe instanceof com.astral.archon.ArchonEntity ? 6.0F : 2.0F;
                    server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, foe.getX(), foe.getY() + 1.0D, foe.getZ(), 10, 0.3D, 0.5D, 0.3D, 0.05D);
                }
                player.heal(Math.min(healed, 14.0F));
                ring(server, player.position(), 6.5D, ParticleTypes.SOUL_FIRE_FLAME);
                server.playSound(null, player.blockPosition(), SoundEvents.SOUL_ESCAPE, SoundSource.PLAYERS, 1.4F, 0.6F);
            }
            player.getCooldowns().addCooldown(this, 240);
            return done(level, stack);
        }
    }

    /** Hacha de la Egida (plateado + rojo): Bastion da resistencia y absorcion, y una onda de choque aleja a los enemigos. */
    public static class AegisAxe extends AstralWeaponItem {
        public AegisAxe() {
            super("aegis_axe", 9.0D, -3.2D);
        }

        @Override
        public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            target.knockback(0.6D, attacker.getX() - target.getX(), attacker.getZ() - target.getZ());
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level instanceof ServerLevel server) {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 2));
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 160, 2));
                for (LivingEntity foe : foesAround(server, player, 5.0D)) {
                    strike(server, player, foe, 6.0F, 1.5F);
                    foe.knockback(1.3D, player.getX() - foe.getX(), player.getZ() - foe.getZ());
                }
                ring(server, player.position(), 4.5D, ParticleTypes.CRIT);
                ring(server, player.position(), 3.0D, ParticleTypes.CLOUD);
                server.playSound(null, player.blockPosition(), SoundEvents.IRON_GOLEM_ATTACK, SoundSource.PLAYERS, 1.4F, 0.7F);
                server.playSound(null, player.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.6F, 1.2F);
            }
            player.getCooldowns().addCooldown(this, 400);
            return done(level, stack);
        }
    }

    /** Cetro Glacial (blanco + azul): Aliento Glacial congela y frena a todo enemigo dentro de un cono. */
    public static class FrostScepter extends AstralWeaponItem {
        public FrostScepter() {
            super("frost_scepter", 4.0D, -2.6D);
        }

        @Override
        public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
            target.setTicksFrozen(target.getTicksRequiredToFreeze() + 40);
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level instanceof ServerLevel server) {
                Vec3 look = player.getLookAngle();
                Vec3 eye = player.getEyePosition();
                for (LivingEntity foe : foesAround(server, player, 10.0D)) {
                    Vec3 to = foe.getEyePosition().subtract(eye);
                    if (to.lengthSqr() > 1.0E-4D && look.dot(to.normalize()) > 0.75D) {
                        strike(server, player, foe, 5.0F, 1.5F);
                        foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3));
                        foe.setTicksFrozen(foe.getTicksRequiredToFreeze() + 80);
                    }
                }
                for (int d = 1; d <= 10; d++) {
                    Vec3 p = eye.add(look.scale(d));
                    double spread = d * 0.08D;
                    server.sendParticles(ParticleTypes.SNOWFLAKE, p.x, p.y, p.z, 8, spread, spread, spread, 0.03D);
                }
                server.playSound(null, player.blockPosition(), SoundEvents.PLAYER_HURT_FREEZE, SoundSource.PLAYERS, 1.4F, 0.8F);
                server.playSound(null, player.blockPosition(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 0.8F, 1.6F);
            }
            player.getCooldowns().addCooldown(this, 140);
            return done(level, stack);
        }
    }

    /** Daga del Vendaval (lima + violeta): ataque rapido; Rafaga te lanza por los aires y aparta a los enemigos. */
    public static class GaleDagger extends AstralWeaponItem {
        public GaleDagger() {
            super("gale_dagger", 3.0D, -1.4D);
        }

        @Override
        public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            attacker.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1));
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            Vec3 look = player.getLookAngle();
            player.setDeltaMovement(look.x * 1.6D, 0.6D + look.y * 0.4D, look.z * 1.6D);
            player.hurtMarked = true;
            player.fallDistance = 0.0F;
            if (level instanceof ServerLevel server) {
                player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 80, 0, false, false, false));
                for (LivingEntity foe : foesAround(server, player, 4.0D)) {
                    foe.knockback(1.1D, player.getX() - foe.getX(), player.getZ() - foe.getZ());
                    strike(server, player, foe, 3.0F, 1.5F);
                }
                server.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 0.3D, player.getZ(), 30, 0.6D, 0.2D, 0.6D, 0.1D);
                server.playSound(null, player.blockPosition(), SoundEvents.PHANTOM_FLAP, SoundSource.PLAYERS, 1.5F, 1.4F);
                server.playSound(null, player.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 0.8F, 1.6F);
            }
            player.getCooldowns().addCooldown(this, 100);
            return done(level, stack);
        }
    }

    /** Varita Arcana (magenta + violeta + cian): rayo magico que salta entre enemigos y los maldice. */
    public static class ArcaneWand extends AstralWeaponItem {
        public ArcaneWand() {
            super("arcane_wand", 2.0D, -2.0D);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level instanceof ServerLevel server) {
                Ray ray = castRay(server, player, 24.0D, 0.8D);
                Vec3 end = ray.end();
                if (!ray.foes().isEmpty()) {
                    LivingEntity first = ray.foes().get(0);
                    end = first.position().add(0.0D, first.getBbHeight() * 0.5D, 0.0D);
                    strike(server, player, first, 12.0F, 1.5F);
                    curse(server, first);
                    int chained = 0;
                    for (LivingEntity other : server.getEntitiesOfClass(LivingEntity.class, first.getBoundingBox().inflate(6.0D),
                            e -> e != first && isFoe(e, player))) {
                        if (chained >= 2) {
                            break;
                        }
                        strike(server, player, other, 6.0F, 1.5F);
                        curse(server, other);
                        server.sendParticles(ParticleTypes.ENCHANT, other.getX(), other.getY() + 1.0D, other.getZ(), 16, 0.4D, 0.6D, 0.4D, 0.5D);
                        chained++;
                    }
                }
                Vec3 dir = end.subtract(ray.start());
                double length = dir.length();
                if (length > 0.01D) {
                    dir = dir.normalize();
                    DustParticleOptions dust = new DustParticleOptions(WishKind.MAGENTA.color(0), 1.3F);
                    for (double d = 0.5D; d <= length; d += 0.4D) {
                        Vec3 p = ray.start().add(dir.scale(d));
                        server.sendParticles(dust, p.x, p.y, p.z, 1, 0.03D, 0.03D, 0.03D, 0.0D);
                    }
                }
                server.playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.PLAYERS, 1.2F, 1.4F);
                server.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.2F);
            }
            player.getCooldowns().addCooldown(this, 30);
            return done(level, stack);
        }

        private static void curse(ServerLevel level, LivingEntity target) {
            MobEffectInstance[] curses = {
                    new MobEffectInstance(MobEffects.WITHER, 100, 0),
                    new MobEffectInstance(MobEffects.BLINDNESS, 80, 0),
                    new MobEffectInstance(MobEffects.WEAKNESS, 120, 0),
                    new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1)};
            target.addEffect(curses[level.random.nextInt(curses.length)]);
        }
    }
}
