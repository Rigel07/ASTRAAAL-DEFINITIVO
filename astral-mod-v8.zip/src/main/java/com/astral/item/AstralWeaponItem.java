package com.astral.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.astral.archon.ArchonEntity;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Base de las armas del astral: reliquias sagradas, indestructibles y con brillo. */
public abstract class AstralWeaponItem extends Item {
    private final Multimap<Attribute, AttributeModifier> modifiers;
    private final String key;

    protected AstralWeaponItem(String key, double damageBonus, double attackSpeedModifier) {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
        this.key = key;
        ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
        builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID,
                "Weapon modifier", damageBonus, AttributeModifier.Operation.ADDITION));
        builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID,
                "Weapon modifier", attackSpeedModifier, AttributeModifier.Operation.ADDITION));
        this.modifiers = builder.build();
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        return slot == EquipmentSlot.MAINHAND ? this.modifiers : super.getDefaultAttributeModifiers(slot);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.astral." + this.key + ".ability").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.astral." + this.key + ".desc").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.astral.relic").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.ITALIC));
    }

    /** Rayo de una habilidad: de donde sale, donde acaba (se corta en los bloques) y los enemigos que atraviesa, del mas cercano al mas lejano. */
    protected record Ray(Vec3 start, Vec3 end, List<LivingEntity> foes) {}

    /** Enemigos hostiles (los Arcontes cuentan): las armas nuevas nunca dañan animales, aldeanos ni jugadores. */
    protected static boolean isFoe(LivingEntity target, Player owner) {
        return target != owner && target.isAlive() && target instanceof Enemy;
    }

    /** Multiplica el dano si el objetivo es un Arconte. */
    protected static float vs(LivingEntity target, float base, float archonMultiplier) {
        return target instanceof ArchonEntity ? base * archonMultiplier : base;
    }

    protected static void strike(ServerLevel level, Player player, LivingEntity target, float amount, float archonMultiplier) {
        target.hurt(level.damageSources().playerAttack(player), vs(target, amount, archonMultiplier));
    }

    protected static List<LivingEntity> foesAround(ServerLevel level, Player player, double radius) {
        return level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius),
                e -> isFoe(e, player) && e.distanceToSqr(player) <= radius * radius);
    }

    protected static Ray castRay(ServerLevel level, Player player, double range, double width) {
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        Vec3 end = start.add(dir.scale(range));
        BlockHitResult hit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (hit.getType() != HitResult.Type.MISS) {
            end = hit.getLocation();
        }
        double length = start.distanceTo(end);
        Set<LivingEntity> found = new LinkedHashSet<>();
        for (double d = 0.0D; d <= length; d += 0.75D) {
            Vec3 point = start.add(dir.scale(d));
            found.addAll(level.getEntitiesOfClass(LivingEntity.class, new AABB(point, point).inflate(width),
                    e -> isFoe(e, player)));
        }
        return new Ray(start, end, new ArrayList<>(found));
    }

    /** Objetivos validos de las habilidades: nada de jugadores, mascotas propias ni soportes de armadura. */
    protected static boolean isValidTarget(LivingEntity target, Player owner) {
        if (target == owner || !target.isAlive() || target instanceof Player || target instanceof ArmorStand) {
            return false;
        }
        return !(target instanceof TamableAnimal pet && pet.isOwnedBy(owner));
    }
}
