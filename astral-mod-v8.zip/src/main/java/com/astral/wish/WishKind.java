package com.astral.wish;

import com.astral.registry.ModEffects;
import com.astral.registry.ModItems;
import java.util.Locale;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.Item;
import org.joml.Vector3f;

/** Los seis deseos. Verde, rojo, amarillo y violeta son comunes; dorado y oscuro son raros, rapidos y esquivos. */
public enum WishKind {
    GREEN(0.35F, 1.00F, 0.45F, false, 0.17D, 12000, 24),
    RED(1.00F, 0.25F, 0.25F, false, 0.17D, 12000, 24),
    YELLOW(1.00F, 0.90F, 0.30F, false, 0.20D, 12000, 24),
    VIOLET(0.70F, 0.40F, 1.00F, false, 0.17D, 12000, 18),
    GOLD(1.00F, 0.78F, 0.15F, true, 0.40D, 18000, 6),
    DARK(0.35F, 0.10F, 0.50F, true, 0.40D, 18000, 6),
    // --- deseos nuevos (se anaden al final para no alterar los guardados de los mundos existentes)
    BLUE(0.30F, 0.65F, 1.00F, false, 0.17D, 12000, 14),
    WHITE(0.92F, 0.97F, 1.00F, false, 0.17D, 12000, 14),
    PINK(1.00F, 0.55F, 0.78F, false, 0.17D, 12000, 14),
    ORANGE(1.00F, 0.55F, 0.15F, false, 0.20D, 12000, 14),
    /** Ultra raro: solo cae en las Lluvias de Deseos y concede tres poderes al azar a la vez. */
    RAINBOW(1.00F, 1.00F, 1.00F, true, 0.45D, 12000, 3),
    /** Coraje: inmunidad al miedo de los Arcontes y el doble de dano contra ellos. */
    CYAN(0.25F, 0.90F, 0.90F, false, 0.17D, 12000, 10),
    SILVER(0.78F, 0.80F, 0.85F, false, 0.17D, 12000, 12),
    LIME(0.60F, 1.00F, 0.25F, false, 0.20D, 12000, 12),
    MAGENTA(0.90F, 0.25F, 0.85F, false, 0.17D, 12000, 12);

    public final float r;
    public final float g;
    public final float b;
    public final boolean rare;
    public final double fallSpeed;
    public final int durationTicks;
    public final int weight;

    WishKind(float r, float g, float b, boolean rare, double fallSpeed, int durationTicks, int weight) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.rare = rare;
        this.fallSpeed = fallSpeed;
        this.durationTicks = durationTicks;
        this.weight = weight;
    }

    /** Color de las particulas; el arcoiris cambia de color con el tiempo. */
    public Vector3f color(int tick) {
        if (this != RAINBOW) {
            return new Vector3f(this.r, this.g, this.b);
        }
        int rgb = Mth.hsvToRgb((tick % 40) / 40.0F, 0.65F, 1.0F);
        return new Vector3f(((rgb >> 16) & 255) / 255.0F, ((rgb >> 8) & 255) / 255.0F, (rgb & 255) / 255.0F);
    }

    public String id() {
        return name().toLowerCase(Locale.ROOT);
    }

    public MobEffect effect() {
        return switch (this) {
            case GREEN -> ModEffects.GREEN.get();
            case RED -> ModEffects.RED.get();
            case YELLOW -> ModEffects.YELLOW.get();
            case VIOLET -> ModEffects.VIOLET.get();
            case GOLD -> ModEffects.GOLD.get();
            case DARK -> ModEffects.DARK.get();
            case BLUE -> ModEffects.BLUE.get();
            case WHITE -> ModEffects.WHITE.get();
            case PINK -> ModEffects.PINK.get();
            case ORANGE -> ModEffects.ORANGE.get();
            case RAINBOW -> ModEffects.RAINBOW.get();
            case CYAN -> ModEffects.CYAN.get();
            case SILVER -> ModEffects.SILVER.get();
            case LIME -> ModEffects.LIME.get();
            case MAGENTA -> ModEffects.MAGENTA.get();
        };
    }

    public Item essence() {
        return switch (this) {
            case GREEN -> ModItems.ESSENCE_GREEN.get();
            case RED -> ModItems.ESSENCE_RED.get();
            case YELLOW -> ModItems.ESSENCE_YELLOW.get();
            case VIOLET -> ModItems.ESSENCE_VIOLET.get();
            case GOLD -> ModItems.ESSENCE_GOLD.get();
            case DARK -> ModItems.ESSENCE_DARK.get();
            case BLUE -> ModItems.ESSENCE_BLUE.get();
            case WHITE -> ModItems.ESSENCE_WHITE.get();
            case PINK -> ModItems.ESSENCE_PINK.get();
            case ORANGE -> ModItems.ESSENCE_ORANGE.get();
            case RAINBOW -> ModItems.ESSENCE_RAINBOW.get();
            case CYAN -> ModItems.ESSENCE_CYAN.get();
            case SILVER -> ModItems.ESSENCE_SILVER.get();
            case LIME -> ModItems.ESSENCE_LIME.get();
            case MAGENTA -> ModItems.ESSENCE_MAGENTA.get();
        };
    }

    /** El deseo al que pertenece una esencia (o null si el objeto no es una esencia). */
    public static WishKind fromEssence(Item item) {
        for (WishKind kind : values()) {
            if (kind.essence() == item) {
                return kind;
            }
        }
        return null;
    }

    public static WishKind byOrdinal(int ordinal) {
        WishKind[] all = values();
        return all[Math.floorMod(ordinal, all.length)];
    }

    public static WishKind byId(String id) {
        for (WishKind kind : values()) {
            if (kind.id().equals(id)) {
                return kind;
            }
        }
        return null;
    }
}
