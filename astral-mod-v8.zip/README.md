# Armas del Astral (Forge 1.20.1)

Mod para Minecraft Forge 1.20.1 (Forge 47.2.0, Java 17): **cuatro reliquias sagradas cute** y **Los Deseos**, almas antiguas que caen del cielo y dan poder al jugador que reciben.

## Los Deseos
Caen del cielo como una gota que brilla de su color (cerca de ti, a unos 45 bloques de altura, de media uno cada 4 minutos). **Ponte debajo**: si te cae encima, te concede su poder (el nombre del efecto sale en tu pantalla de efectos).

| Deseo | Dura | Poder |
|---|---|---|
| **Verde** | 10 min | +4 corazones, regeneras cada segundo, hace crecer los cultivos cercanos y cura a los animales. |
| **Rojo** | 10 min | +4 de ataque, +4 de armadura, resistencia al empuje, inmune al fuego y un aura que **prende fuego a los enemigos** cercanos. |
| **Amarillo** | 10 min | +50 % velocidad y de ataque, visión nocturna, salto alto y **deja luz por donde pasas**. |
| **Violeta** | 10 min | Caída lenta, saltos enormes y un **radar** que hace brillar a todos los seres vivos a 24 bloques. |
| **Dorado** *(raro, solo de día)* | 15 min | +10 corazones, +6 de ataque, +8 de armadura, +4 de dureza, suerte, +20 % velocidad, regeneración, limpia los efectos malos y deja luz. |
| **Oscuro** *(raro, solo de noche)* | 15 min | +9 de ataque, +40 % velocidad de ataque, +30 % velocidad, visión nocturna, **roba el 30 % del daño que haces** como vida y frena a los enemigos cercanos… pero **pierdes 4 corazones**. |

| **Azul** *(nuevo)* | 10 min | +2 corazones, respiras bajo el agua, nadas como un delfín, poder del conducto, apaga el fuego y **te curas en el agua y la lluvia**. |
| **Blanco** *(nuevo)* | 10 min | +3 armadura, resistencia al empuje, **caminas sobre el agua congelándola**, y los enemigos cercanos (y los que golpeas) se **congelan y se frenan**. |
| **Rosa** *(nuevo)* | 10 min | +2 corazones, absorción, **los animales cercanos se enamoran y crían**, curas a jugadores y mascotas a tu alrededor y los enemigos cercanos pierden fuerza. |
| **Naranja** *(nuevo)* | 10 min | **Prisa III**, visión nocturna, resistencia al fuego, +2 ataque, suerte y **30 % de duplicar lo que sueltan los bloques que rompes** (con la herramienta correcta). |
| **Arcoíris** *(ultra raro, solo en Lluvias de Deseos)* | 10 min | +4 corazones, +3 ataque, +4 armadura, suerte, +10 % velocidad, cura, doble experiencia y **te concede además 3 poderes comunes al azar a la vez**. Cae rapidísimo. |

| **Cian (Coraje)** *(nuevo)* | 10 min | +2 ataque, +2 armadura, fuerza, limpia oscuridad/ceguera/náuseas. **Inmune al miedo de los Arcontes y les haces el doble de daño.** |
| **Plateado (Égida)** *(nuevo)* | 10 min | +6 armadura, +3 dureza, +50 % resistencia al empuje, curación lenta y **devuelve el 40 % del daño a quien te golpea**. |
| **Lima (Vendaval)** *(nuevo)* | 10 min | +20 % velocidad, salto alto, caída de pluma y **el viento empuja lejos a los enemigos cercanos**. |
| **Magenta (Arcano)** *(nuevo)* | 10 min | +2 ataque, +2 suerte, **atrae la experiencia cercana** y **30 % de que tu golpe aplique marchitar, ceguera, debilidad, veneno o lentitud**. |

Los deseos dorado, oscuro y arcoíris son los más complicados: caen **el doble de rápido y zigzaguean**, así que hay que perseguirlos. Cuando alguien recibe uno, se avisa a todo el servidor.

### Poderes extra de los deseos clásicos
- **Verde:** además limpia veneno, hambre y wither, y te alimenta un poco.
- **Rojo:** todo lo que golpeas **arde** 5 segundos.
- **Amarillo:** 15 % de que tu golpe **salte como descarga eléctrica** a otros 2 enemigos cercanos.
- **Violeta:** **35 % de esquivar** flechas y demás proyectiles.
- **Dorado:** **doble de experiencia** por cada criatura que derrotas.
- **Oscuro:** cada muerte que provocas te **cura 2 corazones**.

### Armonía astral
Si tienes varios deseos activos a la vez ganas bonificaciones: **2 deseos** → absorción; **3** → resistencia; **4 o más** → regeneración y fuerza.

Si un deseo llega al suelo sin tocar a nadie, se deshace y deja una **Esencia de Deseo** de su color.

## Las armas del astral (reliquias sagradas)
Indestructibles, con brillo y habilidad con clic derecho. Se fabrican **sin forma** (cualquier colocación) con esencias:

| Arma | Habilidad | Receta |
|---|---|---|
| **Báculo de la Estrella Fugaz** | Lanza una estrella que estalla en chispas y daña en área (10 daño directo, 6 alrededor). Enfriamiento 1,5 s. | esencia dorada + 2 violeta + 2 amarilla + 2 fragmentos de amatista + 1 palo |
| **Espada de la Luna Creciente** | Tajo lunar: embestida que corta todo a su paso. Cada golpe ralentiza y marca (brillo) al enemigo. Enfriamiento 4 s. | esencia oscura + 2 violeta + espada de diamante + 2 fragmentos de amatista |
| **Cetro del Sol Naciente** | Pulso solar: cura 4 corazones a jugadores y mascotas a 8 bloques y quema a los enemigos. Enfriamiento 10 s. | esencia dorada + 2 amarilla + 2 roja + vara de blaze + 2 polvo de piedra luminosa |
| **Martillo del Cometa** | Clic derecho: te lanza al cielo. Al caer con él en la mano, el impacto daña y lanza a los enemigos (más daño y radio cuanto más alto caes) y **no recibes daño de caída**. | esencia oscura + 2 roja + 2 verde + bloque de hierro + 1 palo |

Las esencias dorada y oscura son las más difíciles de conseguir: solo salen de los deseos raros que llegan al suelo.

## Almohada Mágica (utilidad de las esencias)
Con **las 6 esencias de deseo + 1 lana (de cualquier color)** se fabrica la **Almohada Mágica** (receta sin forma). Es una sola reliquia con **cuatro poderes distintos según la ranura de armadura** donde la lleves: arrástrala a la ranura de casco, peto, pantalones o botas (con *shift+clic* va a la cabeza).

| Ranura | Modo | Qué hace |
|---|---|---|
| **Cabeza** | Abrazo protector | La almohada se pega a tu cuerpo, como un escudo mullido delante del pecho, y **te protege de cualquier ataque** (solo no frena el vacío ni `/kill`). |
| **Peto** | Siesta flotante | **Abrazas la almohada recostado** y flotas despacio: salta para elevarte en el aire (agáchate para bajar). **Regeneración pasiva** y puedes **dormir** con la tecla **N** (guarda tu punto de reaparición y, si la mitad de los jugadores descansa, amanece). |
| **Pantalones** | Bolsillo mágico | Una almohada pequeña flota junto a tu cadera y **absorbe los objetos cercanos** (y el **agua** si te agachas, como una esponja, guardada en cubos) en un **bolsillo de 162 huecos** (3 páginas de cofre grande). Tecla **B** o clic derecho con ella en la mano para abrirlo. |
| **Botas** | Nube viajera | Pulsa **V** para **montar la nube**: vuelas **muy rápido tumbado boca abajo sobre ella**, subiendo o bajando hacia donde miras (agáchate para descender). Al bajarte tienes unos segundos de caída lenta. |

- Cada almohada tiene su propio bolsillo (se guarda en el mundo, no en el objeto) y es indestructible.
- Las teclas (N, B, V) se pueden cambiar en *Controles → Armas del Astral*.
- Puedes llevar varias almohadas a la vez (una en cada ranura) para tener varios modos.

## Más utilidades para las esencias
- **Altar de Deseos** **No se fabrica: se encuentra en el mundo**, dentro de unos **minitemplos de piedra y cuarzo** (generados en bosques, taigas, colinas, llanuras, desiertos, sabanas, junglas, mesas, pantanos y prados; son **raros**: unos 500-600 bloques entre uno y otro). Cada minitemplo tiene un altar y un **cofre con botín** (esencias, fragmentos de amatista y oro, y con suerte una esencia dorada u oscura). Puedes encontrarlos con `/locate structure astral:altar_shrine`. Si rompes un altar con un pico, se queda en tu inventario y lo puedes llevar a tu base. **Clic derecho con una esencia** y la dejas dentro del altar: **el poder de ese deseo se queda en ti** (no se acaba nunca mientras la esencia siga en el altar, estés donde estés y aunque cambies de dimensión) **hasta que lo retires**. Para retirarlo, haz **clic derecho en el altar** (con cualquier cosa en la mano): recuperas la esencia y el poder se apaga. Solo el **dueño** (quien dejó la esencia) o un operador puede retirarla. Si el altar se rompe o explota, la esencia cae al suelo y el poder se apaga. Puedes tener varios altares con esencias distintas para acumular varios poderes a la vez (y activar la *Armonía astral*). El altar brilla con partículas del color de la esencia que guarda.
- **Brújula de Deseos** (brújula + esencia amarilla + esencia violeta, sin forma). Clic derecho: te dice el **color, la distancia, la altura y la dirección** (norte, noreste...) del deseo más cercano (hasta 160 bloques) y marca el camino con chispas.
- **Esencias de jefe**: el **Wither** suelta esencia oscura (1-2) y roja (2); el **Ender Dragon**, dorada (1-2), violeta (2) y **arcoíris (1)**; el **Warden**, oscura, violeta (1) y **blanca (1-2)**; el **Guardián Anciano**, verde (1-2), amarilla (1) y **azul (1-2)**; el **Wither** también suelta **naranja (1-2)** y el **Evocador** tiene 50 % de soltar una esencia **rosa**. Así las esencias raras se consiguen también sin esperar a los deseos.

## Lluvia de Deseos
Cada noche hay un **10 % de probabilidad** (configurable) de una **Lluvia de Deseos**: durante 30 segundos caen muchos deseos a tu alrededor, y en la lluvia pueden caer de todos los colores a cualquier hora, incluidos el dorado y el oscuro. Se avisa a todo el servidor con un mensaje y un sonido.

## Sonidos y logros
- Sonidos propios (campanitas y coros suaves) cuando aparece un deseo, cuando te elige uno (más grave y largo si es dorado u oscuro), al invocar en el altar y en la lluvia.
- **13 logros** en una pestaña propia ("Armas del Astral"): primer deseo, el elegido (dorado u oscuro), coleccionista de almas (los seis), altar, brújula, alquimista de deseos (las seis esencias a la vez), almohada, reliquia sagrada los cuatro astros (las cuatro armas), *Más allá del arco iris* (deseo arcoíris) y *Espectro completo* (los quince deseos).

## Configuración
Archivo `config/astral-common.toml` (se crea al arrancar): cada cuántos segundos cae un deseo, altura de caída, máximo de deseos a la vez, probabilidad de lluvia, multiplicador de duración de los poderes, si la almohada de la cabeza protege (desactívalo en servidores PvP), radio del bolsillo mágico y velocidad de la nube.

## Comandos (operadores)
- `/astral wish <green|red|yellow|violet|gold|dark|blue|white|pink|orange|rainbow>`: hace caer un deseo sobre ti (para probar).
- `/astral shower`: lanza una Lluvia de Deseos.
- `/give @s astral:wish_essence_gold` y demás para tener esencias; las armas y la almohada están en la pestaña creativa "Armas del Astral".

## Ajustes
- Frecuencia y demás: `config/astral-common.toml` (por defecto, un deseo cada 4 min por jugador).
- Pesos de cada color y velocidades: `WishKind.java`.
- Potencia de los poderes: `WishEffect.java`.

## Compilar con GitHub (sin instalar nada)
1. Sube a un repositorio **este .zip tal cual** (sin descomprimir) y el archivo `.github/workflows/build.yml`
   (créalo con *Add file → Create new file* escribiendo la ruta `.github/workflows/build.yml`).
2. GitHub descomprime el zip, compila y deja el `.jar` en **Actions → último run → Artifacts → mod-jar**.
3. Copia el `.jar` a la carpeta `mods` de Forge 1.20.1.

Compilar en local: `gradle build` (Gradle 8.1.1, JDK 17). El jar queda en `build/libs/`.


## Arcontes (nuevos enemigos)

Seres que **viven de tu miedo**. Aparecen de noche y en la oscuridad (como los monstruos normales) por todo el Overworld, pero son poco comunes. Tienen **70 de vida, 9 de ataque, 6 de armadura** y resisten el empuje.

- **Toman la forma de tus miedos** y la cambian cada pocos segundos (se adaptan: si estás en el agua toman la de ahogo, si estás a oscuras la de sombra). Cada forma tiene su propia apariencia y su propio efecto al golpearte:
  - **Sombra:** oscuridad y ceguera.
  - **Altura:** te elevan con levitación para que luego caigas.
  - **Ahogo:** te quitan aire y te frenan.
  - **Fuego:** te prenden fuego.
  - **Veneno:** veneno y lentitud.
- **Se alimentan del terror:** si estás a menos de 12 bloques te frenan y se curan; cada golpe que te dan los cura aún más.
- **Se teletransportan a tu espalda** cuando no los miras, y a veces se esfuman al recibir un golpe.
- **Se debilitan con la luz:** reciben daño en zonas muy iluminadas (¡y a pleno día!).
- **Cómo vencerlos:** el deseo de **Coraje (cian)** te hace inmune a su miedo y les duplica el daño, y además se hieren al golpearte. El **Plateado** devuelve daño, el **Rojo** y el **Dorado** te dan fuerza bruta.
- **Botín:** 1-2 esencias de deseo al azar, 35 % de esencia **cian (Coraje)**, fragmentos de amatista y 30 de experiencia. El logro *Cara a cara con el miedo* se consigue al derrotar uno.
- Hay un **huevo generador** en la pestaña creativa.


## Armas nuevas (una por color de deseo)

Reliquias indestructibles con habilidad de clic derecho. Se fabrican **sin forma** (shapeless) en la mesa de crafteo. Sus habilidades solo dañan a **enemigos hostiles** (nunca a animales, aldeanos, mascotas ni jugadores) y todas están pensadas para enfrentarse a los **Arcontes**.

| Arma | Receta | Habilidad |
|---|---|---|
| 🩵 **Espada del Coraje** | esencia cian + esencia roja + espada de diamante + 2 lingotes de oro | **Grito de Valor** (30 s): da Coraje (inmunidad al miedo) a los aliados cercanos, limpia efectos de miedo y daña a los enemigos (x2 a Arcontes). Cada golpe a un Arconte hace +5 de daño. |
| ☀️ **Lanza del Alba** | esencia amarilla + dorada + cian + vara de blaze + 2 polvo de piedra luminosa | **Haz de Luz** (8 s): rayo de 28 bloques que atraviesa a todos los enemigos e ilumina el camino. **Hace x3 de daño a Arcontes** (la luz es su debilidad). |
| 🌑 **Guadaña del Eclipse** | esencia oscura + violeta + cian + azada de diamante + 2 fragmentos de amatista | Cada golpe te cura (el doble con Arcontes). **Cosecha de Almas** (12 s): drena a los enemigos a 7 bloques y te devuelve la vida. |
| 🛡️ **Hacha de la Égida** | esencia plateada + roja + hacha de diamante + bloque de hierro + escudo | **Bastión** (20 s): Resistencia III + absorción y una onda de choque que aparta a los enemigos. |
| ❄️ **Cetro Glacial** | esencia blanca + azul + 2 hielo azul + fragmento de amatista + palo | **Aliento Glacial** (7 s): congela y frena a todos los enemigos de un cono de 10 bloques. |
| 🍃 **Daga del Vendaval** | esencia lima + violeta + espada de hierro + 2 plumas + fragmento de amatista | Ataque rapidísimo (te da velocidad al golpear). **Ráfaga** (5 s): te lanza por los aires con caída lenta y aparta a los enemigos. |
| 🔮 **Varita Arcana** | esencia magenta + violeta + cian + 2 fragmentos de amatista + palo | **Rayo Arcano** (1,5 s): rayo mágico que salta a 2 enemigos más y los maldice (marchitar, ceguera, debilidad o lentitud). |

Logro nuevo: **Arsenal astral** (fabricar las 7).
